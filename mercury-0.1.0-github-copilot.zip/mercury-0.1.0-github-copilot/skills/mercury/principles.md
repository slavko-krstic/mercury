# Principles

The design standard for authoring and review, and the rules for writing what a reader acts on.

## Coding principles

Consider all ten against a complete change before it is called done, scaling depth to the change and
marking an inapplicable principle with a brief reason. Do not manufacture relevance or findings for a
small change; a milestone review applies only the principles its local context supports.

1. **Pay complexity once.** Shared code concentrates protocol adaptation, metadata interpretation,
   validation, orchestration and other cross-cutting mechanics. Code facing the domain stays small and
   semantic, while choices affecting behavior, cost or correctness stay visible.
2. **Declare meaning once.** Identity, ownership, requiredness, mutability, visibility and
   availability each have one canonical declaration, from which validation, planning, execution,
   serialization and generated artifacts derive.
3. **Make domain language executable.** Interfaces and types name concepts such as identity,
   operation intent, lifecycle state, data availability and stabilization. Abstractions encode stable
   concepts and invariants; mechanics stay behind them.
4. **Treat identity and state as first-class.** Carry type and meaning with identity. Model lifecycle
   state, provenance, ownership and transitions explicitly, and preserve their invariants through
   shared operations.
5. **Represent intent before implementation.** Express operations, conditions, projections,
   transformations and mutations as composable models that planners and adapters validate, translate
   and execute.
6. **Make scope, cost and mutation explicit.** Reads state their scope and dependencies. Mutations
   state the effects they commit, with precise meanings for missing, null, empty and populated inputs.
   Choices affecting calls and retries stay visible.
7. **Optimize the whole semantic operation.** Treat multi-step execution, retries and callbacks as one
   logical operation: carry operation-scoped context, consolidate boundary work, and preserve the
   caller's requested semantics.
8. **Unify semantics and specialize capabilities.** Common interfaces hold only behavior with one
   stable meaning across implementations; protocol-, service- or operation-specific behavior uses
   explicit capability contracts.
9. **Treat boundary representations as protocols.** Identifiers, callback state, serialized data,
   interface models and generated artifacts are deterministic, versioned compatibility contracts.
   Parse them strictly and verify compatibility and generation freshness.
10. **Use precise semantic contracts and refine them with evidence.** Define equivalence,
    availability, mutation, ordering, error precedence and state transitions explicitly. Prefer the
    smallest coherent abstraction, reuse established helpers and mature libraries, and let tests and
    measured behavior improve the mechanism without changing the contract.

## Review standard

- Correctness is non-negotiable and design quality is a first-class dimension. Prefer tight, simple
  code with clear control flow and the smallest coherent surface; look for an existing helper,
  pattern or abstraction before accepting a parallel mechanism; challenge unneeded layers,
  speculative generality and ceremony; judge whether the change feels native to the codebase.
- Compare each revision with its predecessor. Material growth in mechanisms or reachable states is a
  warning: rederive the invariant and look for deletion, reuse or a broader redesign; keep the
  complexity only when correctness, compatibility, safety or operations require it.
- Source comments state current intent, invariants and constraints, never the history of the work.
- A design finding needs a concrete cost: duplicated behavior, divergent semantics, avoidable
  complexity, an inconsistent boundary, a missed established mechanism, or code materially harder to
  reason about or change.
- Materiality: style, naming alternatives, polish, comment wording, equivalent implementations, tiny
  duplication, unsupported micro-optimizations and edge cases without a credible trigger never
  justify another revision by themselves. A finding that does establishes observable behavior,
  contract, correctness, safety, security, supported performance or systemic maintenance cost.
- Before reporting, if every candidate is a nit or near-nit, report the review clean. Keep the batch
  only when at least one candidate justifies another revision; never inflate one to save the rest.
- Group repeated manifestations of one mechanism into one root-cause finding with every affected
  site. There is no cap on distinct correctness findings.
- No new machinery for an implausible edge case; rare but severe security, data-loss or production
  risks may still justify protection. Before blocking, restarting or repeating a review, recheck the
  current state and take the least costly fully correct path.
- Test the status a claim carries, not only the claim: decisive, verified, corroborated or limiting
  are claims about the evidence. Agreement where both sides recalled is one datum; a premise shared
  with a case that stays unresolved is not the deciding fact.

## Writing for the reader

- **Final state, not the history of the work.** State what is true, what to do, and what is still
  unknown, dated where it can change. Keep the history of the world (when something broke, merged,
  deployed or recovered); cut what was tried, read or corrected. Replace "now", "currently" and "so
  far" with a date or a condition.
- **Name the reader and their question** before drafting, and open with what they most need, usually
  the answer. Put prerequisites and the action where a reader who stops after the first paragraph
  still acts correctly. Keep a claim that could reverse the recommendation next to it, and a limit
  beside the conclusion it bounds.
- **Certainty, claim by claim, in words:** verified (read, run, seen; no hedge), likely (documented or
  inferred; say so), unverified (say so, and what would settle it). Give overall confidence beside the
  conclusion, not at the end, with no self-assessed percentage.
- **Never cut a qualifier for length:** scope and count basis, time boundaries, observed versus
  absent, the certainty level, distinct facts kept distinct, an instruction kept apart from a fact,
  and nothing from outside the evidence.
- **Plain sentences:** one idea each, active voice, plain words, no internal identifiers, at most one
  bold point per section. Cut intensifiers, lines telling the reader what to notice, and sentences
  that could move unchanged to another report. Invent nothing: mark a missing fact rather than guess.
- **Test it twice** when the reader will act on it: a fresh checker compares every claim with the
  inputs, with one planted defect it is not told about, and checks the corrected text again; then a
  fresh reader given only the first 60 words answers the reader's questions.
