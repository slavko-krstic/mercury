# Delegation

How a commander starts a fresh-context check, and the only things that cross between agents: a brief
and a result. A counterpart reads this file and its brief.

## Independence, strongest first

1. The host's own subagent, started fresh: never a fork or copy of the commander's conversation.
2. A second non-interactive run of the same assistant's command-line tool, from the same directory,
   with the brief as its prompt (for example `claude -p`, `codex exec -`, `copilot --prompt`).
3. A new chat or session the user opens with the brief, pasting the result back.
4. A recheck in the same context with the checks written before rereading. Label it `self-review`;
   it never counts as independent.

| Host | Fresh counterpart | Rung |
| --- | --- | --- |
| Claude Code | Agent tool, ordinary subagent; never a fork | 1 |
| VS Code, local harness | `runSubagent` | 1 |
| VS Code Copilot harness, Copilot CLI, JetBrains, Codex CLI | the host's subagent or `task` tool; its starting input is undocumented, so read `received:` | 1 |
| Cursor, Gemini CLI | subagents | 1 |
| Copilot cloud agent | none reliable | 4; the pull request's human review is the independent check |
| Visual Studio | none | 3 or 4 |
| Microsoft 365 Copilot, Copilot Studio | the chat edition | 3 |

A separate context is not by itself blind, so every result opens with `received:`. Start a
counterpart on your own model, never a smaller one.

## Spawn where you can; otherwise request

A commander that is itself a subagent starts its counterparts if its host allows nesting. Otherwise
it adds a row to its ledger's `## Delegation requests` (the check, its brief path, its result path)
and returns with `next:` naming them. The session above starts each check, has the counterpart write
the named result file, and resumes the commander (by continuing it, or with a fresh commander that
reads the ledger). The resumed commander marks the request done when it reads the result.

## One writer

The commander owns the ledger and every write to the workspace. A counterpart writes only its result
file; the session above writes only a requested result file. Never run parallel writers. Delegate for
independence (review, challenge, tests written from requirements) and for read-only breadth (research
sub-questions, exploration that would flood your context).

## Budget

If `config.md` sets `token_budget`, compare the objective's measured spend (its `## Cost` lines)
before starting each check: past 80%, take the smallest sufficient next step; past 100%, ask the
user first. Unmeasured runs count as unknown, so on a host that reports nothing the budget is
advisory, and you say so.

## The brief


`.mercury/work/<objective>/briefs/<check-id>.md`, overwritten each round:

```text
mercury: 1
MERCURY BRIEF <check-id> round <k> revision <rev<n> = commit, or the paths and their times>
check: <what to establish>   serves: <the role step>
objective: <one line>
read: <exact paths, revision range, URLs, commands that reproduce the observations>
untracked: <untracked files present, which are outside the revision>
withheld: <what you are not given, and why>
rules: read only what is named and what it leads to; edit nothing but the result file; make no
  external write; run your checks; record the tree at start and finish; follow delegation.md
coverage: <the ordered checklist to complete, each item with the read or command that settles it>
result: .mercury/work/<objective>/results/<check-id>.round<k>.md
```

## What crosses

- Defect discovery: the work, repository access and the observations it produced. Then, whatever that
  round found, a conformance round given the requirements.
- Challenge: the facts and the proposition, never the defense. The proposition survives only if no
  objection is confirmed.
- Exact files cross by path, never as summaries.
- Always withheld: the commander's rationale and conclusions, other counterparts' findings, the
  preferred outcome, and who wrote the work ("the change under review").
- A thread round includes that thread's own positions and their checks, nothing from other threads.

## As the counterpart

1. At start, in the project directory, record `git rev-parse HEAD` and
   `git status --porcelain --untracked-files=no -- . ':(exclude).mercury'`.
2. Read what the brief names; run the checks that could prove the work wrong. Prefer executing to
   rereading.
3. Complete every coverage item, naming the read or command that settled it.
4. At finish, record the same two commands again, then write the result. If they differ from the
   start, say so: the tree moved under you.

```text
mercury: 1
MERCURY RESULT <check-id> round <k> revision <as briefed>
start: <HEAD> | <status lines, or empty>
finish: <HEAD> | <status lines, or empty>
received: <everything you were given: files, paths, text, outputs>
verdict: findings | clean | blocked: <cause>

## Candidates
### <check-id>.F<n> (decisive | context): <claim>
where: <path:line or source>   trigger: <input or condition>   impact: <what goes wrong>
falsifier: <what would show this wrong>
check: <command or read> -> <output, at most three lines>

## Unknowns
- <question> | <impact> | <probe> | <result>

## Coverage
- <item>: <the read or command that established it>
```

A counterpart that could not run its checks returns `blocked` with the cause, never `clean`.

## Receiving a result

- Apply it only if its check id, round and revision match the brief and its start and finish
  records match each other and the revision. Otherwise re-check its candidates on a clean revision.
- Discard it as not independent when `received:` shows your reasoning or another counterpart's
  findings, and rerun the check with a corrected brief.
- A malformed or missing result is `blocked`: re-brief once, then report the second failure. A
  `clean` without coverage evidence is not accepted; re-brief for the evidence.
- Post your positions on every open candidate of the result in one round.
- Add one `## Cost` line: time, agent, check, round, the tokens the host reported (or
  `unmeasured`), and where the figure came from.
