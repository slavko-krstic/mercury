mercury: 1
objective: <YYYYMMDD-short-name>   role: <role>   tier: <1|2>
status: <state>   updated: <UTC time>
question: <one line>
loaded: <each Mercury file and protocol addition read for this objective>
next: <the next action; or what it waits on, who owns that, and the exact unblock action>

<!--
Written only by the objective's commander.

Identity. The objective is <YYYYMMDD>-<short-name>, with -2, -3 appended on a collision. Candidates
are C<n>; delegated checks are <kind>-<n> (review-1, verify-2); a counterpart's findings are
<check-id>.F<n>. Results are results/<check-id>.round<k>.md, never overwritten.

States:
  author: IN_PROGRESS | READY | BLOCKED
  researcher-commander: IN_PROGRESS | ANSWERED | UNANSWERED
  oncall-commander: ACTIVE | HANDOFF_READY | REMEDIATION_AT_GATE | REMEDIATION_SUCCESSFUL
  protocol-doctor: IN_PROGRESS | DONE | BLOCKED
Terminal states: READY ANSWERED UNANSWERED HANDOFF_READY REMEDIATION_SUCCESSFUL DONE
Done states: READY ANSWERED REMEDIATION_SUCCESSFUL DONE
Waiting states: BLOCKED REMEDIATION_AT_GATE
A terminal state has no open thread, unknown or delegation request, no unrun decisive claim, and a
written report. A done state also has no decisive claim or unknown left unmeasured: a check that
could not run leaves the objective waiting, or an incident or question at HANDOFF_READY or
UNANSWERED saying what would settle it. A waiting state names on the next: line what is waited on, who
owns it, and the unblock action.

Bounds. Soft cap 64 KB: past it, compact each resolved thread to one line (claim, outcome, decisive
check, fix reference). Evidence is a reference (path and line, command, URL, time) plus at most three
lines of excerpt; never copy source code. At a terminal state, delete the briefs and results once
their decisive excerpts are here.

Lessons. When creating a ledger, read each lesson in .mercury/lessons/ whose question bears on the
work, and add its test to your checks. At a terminal state, unless config.md says lessons: off, write
each lesson that generalizes as a new file, .mercury/lessons/<objective>-<short-name>.md, never
edited afterwards:
  mercury: 1
  lesson: <the reusable question it answers>
  test: <the first check to run>
  applies when: <the condition>
  from: <objective>, <date>
At most 40: past that, delete the oldest; only the protocol-doctor merges duplicates.

Keep each table's header line, write a | inside a cell as \|, and delete these comments.
-->

## Context used

<!-- pointers into .mercury/context.md, notes and protocol context, plus anything objective-specific -->

## Claims

| id | rank | claim | check | grounding | status |
| --- | --- | --- | --- | --- | --- |

<!-- rank: decisive | context. grounding: ran | read | recalled. status: unrun | passed | failed | unmeasured -->

## Threads

<!--
One block per candidate:
### C1 g1: <claim, as its current generation states it>
falsifier: <what would show it wrong>
- counterpart open g1: <check run> -> <what it produced>
- author confirm g1: <own check> -> <what it produced>
outcome: open | needs reaffirmation | confirmed g<n> | withdrawn g<n> | disputed
Positions: open, revise (a new generation), confirm, withdraw, challenge, question. Every position
but open and question names the poster's own check and what it produced. Any change to a claim's
wording is a new generation, and agreement on an older one does not carry forward; sharpening the
other side's claim is a new claim, checked before it is posted. A resolved outcome names the
thread's current generation: confirmed needs one side's open or revise and the other side's confirm
on it, withdrawn needs a withdraw and both sides on it, and neither side's last position there may
disagree. disputed needs both sides' positions.
-->

## Unknowns

| question | impact | probe | result |
| --- | --- | --- | --- |

## Delegation requests

| check | brief | result | state |
| --- | --- | --- | --- |

<!-- state: open | done. Only the commander writes this ledger; the session above writes only the named result file. -->

## Revisions

| rev | commit | range | read by | interval |
| --- | --- | --- | --- | --- |

<!-- interval: checked | unchecked | changed (the round's interval record, per result) -->

## Audit

<!-- AUDIT-<n>: why the check missed it | the check | sibling scope | failing witness | current result -->

## Cost

| time (UTC) | agent | check | round | tokens | source |
| --- | --- | --- | --- | --- | --- |

<!-- One line per agent run: each counterpart, and your own turns where the host shows their usage.
tokens: the figure the host reported, or unmeasured; never an estimate. -->

## Report
