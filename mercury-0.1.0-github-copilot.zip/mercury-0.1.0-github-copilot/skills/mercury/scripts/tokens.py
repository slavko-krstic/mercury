#!/usr/bin/env python3
"""Sum the token usage hosts record in their local session files. Read-only, offline, standard library
only; prints counts and file names, never session content.

    tokens.py --objective <slug>        sessions whose records mention .mercury/work/<slug>/
    tokens.py --session FILE [FILE...]  exactly these record files
    options: --claude-dir DIR  --codex-dir DIR  --days N (default 30)  --json

Supported record formats, each tested against real records:
  Claude Code: <claude-dir>/projects/*/<session>.jsonl and <session>/subagents/*.jsonl; each
    assistant message's usage, counted once per message.
  Codex CLI: <codex-dir>/sessions/**/rollout-*.jsonl; the session's last cumulative token count.
Every other host is reported unsupported; nothing is estimated.

Attribution is by record file: a session whose records mention the objective's work directory is
counted whole, so a session that worked on several objectives is counted for each of them.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

UNSUPPORTED = ("GitHub Copilot (VS Code, CLI, cloud agent, JetBrains, Visual Studio)", "Cursor",
               "Gemini CLI", "OpenCode", "Goose", "Amp", "Windsurf", "Roo Code", "Kiro", "Cline",
               "chat assistants")
CLAUDE_FIELDS = ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens",
                 "output_tokens")
CODEX_FIELDS = ("input_tokens", "cached_input_tokens", "cache_write_input_tokens", "output_tokens",
                "reasoning_output_tokens", "total_tokens")


def claude_usage(path: Path) -> dict:
    """One usage per assistant message: a message written as several lines repeats its id, and the
    last line written carries its final usage."""
    messages = {}
    with path.open(encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if '"usage"' not in line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            message = record.get("message")
            if record.get("type") != "assistant" or not isinstance(message, dict):
                continue
            usage = message.get("usage")
            if not isinstance(usage, dict):
                continue
            key = (message.get("id") or record.get("uuid"), record.get("requestId"))
            messages[key] = usage
    totals = dict.fromkeys(CLAUDE_FIELDS, 0)
    for usage in messages.values():
        for field in CLAUDE_FIELDS:
            value = usage.get(field)
            if isinstance(value, int):
                totals[field] += value
    totals["messages"] = len(messages)
    return totals


def codex_usage(path: Path) -> dict:
    """The rollout's last cumulative token count is the session's total."""
    last = None
    with path.open(encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if '"token_count"' not in line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            payload = record.get("payload")
            if record.get("type") == "event_msg" and isinstance(payload, dict) \
                    and payload.get("type") == "token_count":
                info = payload.get("info")
                if isinstance(info, dict) and isinstance(info.get("total_token_usage"), dict):
                    last = info["total_token_usage"]
    totals = {field: int((last or {}).get(field) or 0) for field in CODEX_FIELDS}
    totals["reported"] = last is not None
    return totals


def host_of(path: Path) -> str:
    return "codex" if path.name.startswith("rollout-") else "claude"


def candidates(claude_dir: Path, codex_dir: Path, days: float) -> list[Path]:
    cutoff = time.time() - days * 86400
    found = []
    roots = [(claude_dir / "projects", ("*.jsonl", "*/subagents/*.jsonl")),
             (codex_dir / "sessions", ("**/rollout-*.jsonl",))]
    for root, patterns in roots:
        if not root.is_dir():
            continue
        for project in ([root] if root.name == "sessions" else sorted(root.iterdir())):
            if not project.is_dir():
                continue
            for pattern in patterns:
                for path in project.glob(pattern):
                    try:
                        if path.stat().st_mtime >= cutoff:
                            found.append(path)
                    except OSError:
                        continue
    return sorted(set(found))


def mentions(path: Path, needles: tuple) -> bool:
    try:
        data = path.read_bytes()
    except OSError:
        return False
    return any(needle in data for needle in needles)


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--objective")
    target.add_argument("--session", nargs="+", type=Path)
    home = Path.home()
    parser.add_argument("--claude-dir", type=Path,
                        default=Path(os.environ.get("CLAUDE_CONFIG_DIR") or home / ".claude"))
    parser.add_argument("--codex-dir", type=Path,
                        default=Path(os.environ.get("CODEX_HOME") or home / ".codex"))
    parser.add_argument("--days", type=float, default=30.0)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if args.session:
        files = [p for p in args.session if p.is_file()]
        missing = [str(p) for p in args.session if not p.is_file()]
        if missing:
            print(f"cannot read: {', '.join(missing)}", file=sys.stderr)
            return 2
    else:
        slug = args.objective.encode("utf-8")
        needles = (b".mercury/work/" + slug + b"/", b".mercury\\\\work\\\\" + slug + b"\\\\",
                   b".mercury\\work\\" + slug + b"\\")
        files = [p for p in candidates(args.claude_dir, args.codex_dir, args.days)
                 if mentions(p, needles)]
    sessions, totals = [], {"claude": dict.fromkeys(CLAUDE_FIELDS, 0),
                            "codex": dict.fromkeys(CODEX_FIELDS, 0)}
    for path in files:
        host = host_of(path)
        usage = claude_usage(path) if host == "claude" else codex_usage(path)
        sessions.append({"host": host, "file": path.name, "usage": usage})
        for field in totals[host]:
            totals[host][field] += usage[field]
    result = {"sessions": sessions, "totals": totals, "files": len(files),
              "unsupported": list(UNSUPPORTED)}
    if args.json:
        print(json.dumps(result, indent=1, sort_keys=True))
        return 0
    for s in sessions:
        counts = ", ".join(f"{k} {v}" for k, v in s["usage"].items())
        print(f"{s['host']}  {s['file']}  {counts}")
    for host, counts in totals.items():
        print(f"total {host}: " + ", ".join(f"{k} {v}" for k, v in counts.items()))
    print(f"{len(files)} session files; unsupported hosts: {'; '.join(UNSUPPORTED)}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
