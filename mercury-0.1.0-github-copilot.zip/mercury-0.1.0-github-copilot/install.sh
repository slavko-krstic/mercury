#!/bin/sh
# Mercury installer for macOS, Linux, Git Bash and WSL. POSIX sh; needs no network, no
# administrator rights and no Python. Copies skills/mercury into each selected assistant's skill
# root as a real copy, with an ownership manifest, and sets up the project's .mercury/ folder.
#
#   sh install.sh                          ask four questions, then install
#   sh install.sh --project DIR [options]  install for one project (the default is this folder)
#   sh install.sh --user [options]         install for every project of this user
#
# Options: --hosts copilot,claude,agents,kiro,cline   --queue TEXT   --queue-read COMMAND
#          --authority ACTION=allowed|never|ask[,...]  --pointer   --update   --refresh-context
#          --uninstall   --dry-run   --yes (no questions)   --help
set -u

PKG=$(cd "$(dirname "$0")" && pwd)
SRC="$PKG/skills/mercury"
HOME_DIR=${HOME:?HOME is not set}
SCOPE=""; PROJECT=""; HOSTS=""; QUEUE=""; QUEUE_READ=""; AUTHORITY=""
POINTER=0; MODE=install; DRY=0; ASK=1; SAW_FLAG=0
ACTIONS="push open_pull_request comment change_ticket close_ticket message_people deploy change_production"
MARK_BEGIN="<!-- mercury:begin -->"
MARK_END="<!-- mercury:end -->"

say() { printf '%s\n' "$*"; }
die() { printf 'mercury install: %s\n' "$*" >&2; exit 1; }
act() { if [ "$DRY" = 1 ]; then say "would: $*"; else "$@" || die "could not $*"; fi; }

usage() { sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; exit 0; }

while [ $# -gt 0 ]; do
  SAW_FLAG=1
  case "$1" in
    --project) [ $# -ge 2 ] || die "--project needs a folder"; SCOPE=project; PROJECT=$2; shift ;;
    --user) SCOPE=user ;;
    --hosts) [ $# -ge 2 ] || die "--hosts needs a list"; HOSTS=$2; shift ;;
    --queue) [ $# -ge 2 ] || die "--queue needs a value"; QUEUE=$2; shift ;;
    --queue-read) [ $# -ge 2 ] || die "--queue-read needs a command"; QUEUE_READ=$2; shift ;;
    --authority) [ $# -ge 2 ] || die "--authority needs action=value pairs"; AUTHORITY=$2; shift ;;
    --pointer) POINTER=1 ;;
    --update) MODE=update ;;
    --refresh-context) MODE=refresh ;;
    --uninstall) MODE=uninstall ;;
    --dry-run) DRY=1 ;;
    --yes) ASK=0 ;;
    --help|-h) usage ;;
    *) die "unknown option $1 (try --help)" ;;
  esac
  shift
done
[ -f "$SRC/SKILL.md" ] || die "run this from the Mercury package: $SRC/SKILL.md is missing"

sha256() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | cut -d' ' -f1
  elif command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | cut -d' ' -f1
  else openssl dgst -sha256 "$1" | sed 's/.*= *//'; fi
}

detect_hosts() {
  found=""
  { [ -d "$HOME_DIR/.copilot" ] || command -v copilot >/dev/null 2>&1 || command -v code >/dev/null 2>&1; } && found="$found,copilot"
  { [ -d "$HOME_DIR/.claude" ] || command -v claude >/dev/null 2>&1; } && found="$found,claude"
  { [ -d "$HOME_DIR/.codex" ] || [ -d "$HOME_DIR/.cursor" ] || [ -d "$HOME_DIR/.gemini" ] || [ -d "$HOME_DIR/.agents" ] ||
    command -v codex >/dev/null 2>&1 || command -v gemini >/dev/null 2>&1 || command -v cursor >/dev/null 2>&1; } && found="$found,agents"
  { [ -d "$HOME_DIR/.kiro" ] || command -v kiro >/dev/null 2>&1; } && found="$found,kiro"
  found=${found#,}
  [ -n "$found" ] || found="copilot,claude,agents"
  say "$found"
}

# The skill roots one host reads, by scope (design section 14); empty when the host has none.
roots_for() {
  case "$1:$2" in
    copilot:project) say "$PROJECT/.github/skills" ;;
    copilot:user) say "$HOME_DIR/.copilot/skills" ;;
    claude:project|cline:project) say "$PROJECT/.claude/skills" ;;
    claude:user) say "$HOME_DIR/.claude/skills" ;;
    cline:user) say "$HOME_DIR/.cline/skills" ;;
    agents:project) say "$PROJECT/.agents/skills" ;;
    agents:user) say "$HOME_DIR/.agents/skills" ;;
    kiro:project) say "$PROJECT/.kiro/skills" ;;
    kiro:user) say "$HOME_DIR/.kiro/skills" ;;
  esac
}

# One root per line, so a project path with spaces stays whole; callers read it line by line.
selected_roots() {
  scope=$1
  printf '%s\n' "$2" | tr ',' '\n' | while read -r host; do
    [ -n "$host" ] && roots_for "$host" "$scope"
  done | sort -u
}

# The hosts the last install chose: config.md's last hosts value for a project, and for a user
# install every host whose skill root holds a manifest.
saved_hosts() {
  if [ "$SCOPE" = project ]; then
    [ -f "$PROJECT/.mercury/config.md" ] || return 0
    awk 'index($0, "hosts: ") == 1 { v = substr($0, 8) } END { if (v !~ /^</) print v }' "$PROJECT/.mercury/config.md"
  else
    found=""
    for host in copilot claude agents kiro cline; do
      [ -f "$(roots_for "$host" user)/mercury/.mercury-manifest" ] && found="$found,$host"
    done
    say "${found#,}"
  fi
}

check_hosts() {
  for host in $(printf '%s' "$HOSTS" | tr ',' ' '); do
    case "$host" in copilot|claude|agents|kiro|cline) ;; *) die "unknown host $host (use copilot, claude, agents, kiro or cline)" ;; esac
  done
}

package_files() { (cd "$SRC" && find . -type f ! -name '*.pyc' ! -path '*/__pycache__/*' | sed 's|^\./||' | LC_ALL=C sort); }

recorded_hash() { [ -f "$1" ] && awk -v p="$2" 'substr($0, 67) == p { print substr($0, 1, 64) }' "$1"; }

# A path inside the skill folder: relative, with no empty, . or .. part, no backslash and no colon,
# so it cannot leave the folder or name a drive or a stream.
confined_rel() {
  case "$1" in ""|/*|*/|*\\*|*:*|*//*) return 1 ;; esac
  case "/$1/" in */./*|*/../*) return 1 ;; esac
  return 0
}

# Refuse a skill folder that is a link or holds one, and a manifest line that is not a digest and a
# confined path. Either would let an install, update or uninstall write or delete a file outside the
# skill.
check_skill_folder() {
  if [ -d "$1" ]; then
    # find examines a link, the skill folder included, without following it.
    link=$(find "$1" -type l -print 2>/dev/null | head -n 1)
    [ -n "$link" ] && die "$link is a link inside the Mercury skill folder; remove it and run again; nothing was changed"
  fi
  [ -f "$2" ] || return 0
  bad=$(awk 'length($0) < 67 || substr($0, 1, 64) !~ /^[0-9a-f]+$/ || substr($0, 65, 2) != "  " { print NR; exit }' "$2")
  [ -n "$bad" ] && die "$2 line $bad is not a manifest line; nothing was changed"
  awk '{ print substr($0, 67) }' "$2" | while IFS= read -r rel; do
    confined_rel "$rel" && continue
    printf 'mercury install: %s names %s, which is outside %s; nothing was changed\n' "$2" "$rel" "$1" >&2
    exit 1
  done || exit 1
}

# Check every skill folder a run will change before it changes any (check_skill_folder), so a refusal
# leaves every host's copy as it was. Uninstall leaves a folder without a manifest alone, so for it
# ($2 = uninstall) only a folder with one is checked.
check_roots() {
  while IFS= read -r root; do
    [ "$2" = uninstall ] && [ ! -f "$root/mercury/.mercury-manifest" ] && continue
    check_skill_folder "$root/mercury" "$root/mercury/.mercury-manifest"
  done < "$1"
}

install_root() {
  root=$1; dest="$root/mercury"; manifest="$dest/.mercury-manifest"
  had_manifest=0; [ -f "$manifest" ] && had_manifest=1
  [ -d "$dest" ] && [ "$had_manifest" = 0 ] && say "  $dest has no manifest: adopting files that match this package"
  act mkdir -p "$dest"
  tmp="$dest/.mercury-manifest.tmp.$$"
  [ "$DRY" = 1 ] || : > "$tmp" || die "could not write $tmp"
  kept=0
  for rel in $(package_files); do
    new=$(sha256 "$SRC/$rel"); target="$dest/$rel"
    if [ -f "$target" ]; then
      cur=$(sha256 "$target")
      old=""; [ "$had_manifest" = 1 ] && old=$(recorded_hash "$manifest" "$rel")
      if [ "$cur" = "$new" ]; then :
      elif [ -n "$old" ] && [ "$cur" = "$old" ]; then act cp "$SRC/$rel" "$target"
      else act cp "$SRC/$rel" "$target.new"; kept=$((kept + 1)); say "  kept your edit of $target; the new version is $target.new"
      fi
    else
      act mkdir -p "$(dirname "$target")"; act cp "$SRC/$rel" "$target"
    fi
    [ "$DRY" = 1 ] || printf '%s  %s\n' "$new" "$rel" >> "$tmp" || die "could not write $tmp"
  done
  if [ "$had_manifest" = 1 ]; then
    awk '{ print substr($0, 67) }' "$manifest" | while IFS= read -r rel; do
      [ -f "$SRC/$rel" ] && continue
      target="$dest/$rel"
      if [ -f "$target" ] && [ "$(sha256 "$target")" = "$(recorded_hash "$manifest" "$rel")" ]; then act rm -f "$target"
      elif [ -f "$target" ]; then say "  $target is no longer part of Mercury but you edited it, so it stays"; fi
    done || exit 1
  fi
  if [ "$DRY" = 0 ]; then mv "$tmp" "$manifest" || die "could not write $manifest"; fi
  say "  installed $dest"
}

uninstall_root() {
  root=$1; dest="$root/mercury"; manifest="$dest/.mercury-manifest"
  [ -f "$manifest" ] || { [ -d "$dest" ] && say "  $dest has no manifest, so nothing there is known to be Mercury's; left alone"; return 0; }
  awk '{ print substr($0, 67) }' "$manifest" | while IFS= read -r rel; do
    target="$dest/$rel"
    [ -f "$target" ] || continue
    if [ "$(sha256 "$target")" = "$(recorded_hash "$manifest" "$rel")" ]; then act rm -f "$target"
    else say "  kept $target: you edited it"; fi
  done || exit 1
  act rm -f "$manifest"
  if [ "$DRY" = 0 ]; then
    find "$dest" -depth -type d -empty -exec rmdir {} \; 2>/dev/null
  fi
  if [ -d "$dest" ]; then say "  $dest still holds files you changed or added"; else say "  removed $dest"; fi
}

warn_skew() {
  other=$1
  selected_roots "$other" "$HOSTS" | while IFS= read -r root; do
    v="$root/mercury/VERSION"
    if [ -f "$v" ] && [ "$(cat "$v")" != "$(cat "$SRC/VERSION")" ]; then
      say "  note: $root/mercury is version $(cat "$v") at $other scope; hosts disagree on which copy wins, so update or remove it"
    fi
  done
}

pointer_files() {
  case ",$HOSTS," in *,copilot,*) say "$PROJECT/.github/copilot-instructions.md" ;; esac
  case ",$HOSTS," in *,agents,*|*,claude,*|*,kiro,*|*,cline,*) say "$PROJECT/AGENTS.md" ;; esac
}

add_pointer() {
  file=$1
  grep -qF "$MARK_BEGIN" "$file" 2>/dev/null && return 0
  act mkdir -p "$(dirname "$file")"
  if [ "$DRY" = 0 ]; then
    lead=""; [ -s "$file" ] && lead=yes
    { if [ -n "$lead" ]; then printf '\n'; fi
      printf '%s\nUse the mercury skill for authoring, review, incidents, ticket queues and research here: say "use Mercury".\n%s\n' "$MARK_BEGIN" "$MARK_END"
    } >> "$file" || die "could not write $file"
  fi
  say "  added the Mercury pointer to $file"
}

remove_pointer() {
  file=$1
  grep -qxF "$MARK_BEGIN" "$file" 2>/dev/null || return 0
  if ! awk -v b="$MARK_BEGIN" -v e="$MARK_END" '$0 == b { if (open) bad = 1; open = 1 }
      $0 == e { if (!open) bad = 1; open = 0 } END { exit (bad || open) }' "$file"; then
    say "  left $file as it is: a Mercury pointer there has lost a marker line, so remove that block by hand"
    return 0
  fi
  if [ "$DRY" = 0 ]; then
    awk -v b="$MARK_BEGIN" -v e="$MARK_END" '
      $0 == b { skip = 1; held = 0; next }
      $0 == e { skip = 0; next }
      skip { next }
      { if (held) print ""; held = 0; if ($0 == "") { held = 1; next } print }
      END { if (held) print "" }' "$file" > "$file.mercury.$$" || die "could not write $file"
    mv "$file.mercury.$$" "$file" || die "could not write $file"
  fi
  say "  removed the Mercury pointer from $file"
}

# --- Workspace state ------------------------------------------------------------------------------
# Fingerprints follow templates/context.md, the one definition scripts/check.py computes too.

US=$(printf '\037')
GIT_TOP=""; PROJECT_REAL=""

# Run once, in the main shell, before any fingerprint.
workspace_init() {
  GIT_TOP=$(git -C "$PROJECT" rev-parse --show-toplevel 2>/dev/null) || GIT_TOP=""
  PROJECT_REAL=$(cd "$PROJECT" && pwd -P)
}
in_git() { [ -n "$GIT_TOP" ]; }

# A source-table path made absolute: it is relative to the project, absolute, or under ~/.
source_target() {
  # shellcheck disable=SC2088 # these patterns match a literal ~ written in the table
  case "$1" in
    "~") t=$HOME_DIR ;;
    "~/"*) t="$HOME_DIR/${1#??}" ;;
    /*|[A-Za-z]:[\\/]*) t=$1 ;;
    *) t="$PROJECT/$1" ;;
  esac
  while [ "$t" != / ] && [ "$t" != "${t%/}" ]; do t=${t%/}; done
  say "$t"
}

# Whether git, run in a directory, reports the project's repository; a nested repository, or none,
# is somewhere else.
in_project_repo() { in_git && [ "$(git -C "$1" rev-parse --show-toplevel 2>/dev/null)" = "$GIT_TOP" ]; }

# The existing files under a directory, relative to it, one per line, leaving out every file in a
# .git or .mercury directory below it, and in a node_modules directory too when $2 is given. A listing
# that fails is not an empty one: when git fails or warns, or the walk meets a folder it cannot open,
# this prints nothing, says the first error on standard error and returns 1.
dir_files() {
  listing=$(mktemp) && raw=$(mktemp) && errors=$(mktemp) || return 1
  if in_project_repo "$1"; then
    git -C "$1" ls-files -z --cached --others --exclude-standard > "$raw" 2> "$errors" &&
      tr '\0' '\n' < "$raw" > "$listing"
  else
    (cd "$1" && find . \( -name .git -o -name .mercury ${2:+-o -name node_modules} \) -type d -prune \
      -o \( -type f -o -type l \) -print) > "$listing" 2> "$errors"
  fi
  status=$?
  rm -f "$raw"
  if [ "$status" -ne 0 ] || [ -s "$errors" ]; then
    sed -n '1s/^/  /p' "$errors" >&2; rm -f "$listing" "$errors"; return 1
  fi
  sed 's|^\./||' "$listing" |
    if [ -n "${2:-}" ]; then awk '!/(^|\/)(\.git|\.mercury|node_modules)\//'; else awk '!/(^|\/)\.(git|mercury)\//'; fi |
    while IFS= read -r f; do [ -f "$1/$f" ] && say "$f"; done
  rm -f "$listing" "$errors"
}

# One fingerprint per line for the absolute paths read from standard input.
file_fps() {
  if in_git; then tr '\n' '\0' | xargs -0 git -C "$PROJECT" hash-object -- 2>/dev/null | sed 's/^/git:/'
  else
    while IFS= read -r f; do
      stat -L -c 'stat:%s:%Y' "$f" 2>/dev/null || stat -L -f 'stat:%z:%m' "$f" 2>/dev/null
    done
  fi
}

# dir:<SHA-256 of one "<fingerprint> <path>\n" line per file, sorted by its path relative to the directory>.
dir_fp() {
  if ! { names=$(mktemp) && prints=$(mktemp) && list=$(mktemp); }; then
    say "dir:unreadable"; say "  cannot create temporary files to fingerprint $1" >&2; return 0
  fi
  if ! dir_files "$1" > "$list"; then
    say "dir:unreadable"; say "  cannot list every file under $1, so its fingerprint is dir:unreadable" >&2
    rm -f "$names" "$prints" "$list"; return 0
  fi
  LC_ALL=C sort "$list" > "$names"
  [ -s "$names" ] && while IFS= read -r f; do say "$1/$f"; done < "$names" | file_fps > "$prints"
  if [ "$(($(wc -l < "$names")))" -eq "$(($(wc -l < "$prints")))" ]; then
    paste -d ' ' "$prints" "$names" > "$list"; say "dir:$(sha256 "$list")"
  else
    say "dir:unreadable"; say "  cannot read every file under $1, so its fingerprint is dir:unreadable" >&2
  fi
  rm -f "$names" "$prints" "$list"
}

# A source's fingerprint, or nothing when it no longer exists.
fingerprint() {
  t=$(source_target "$1")
  if [ -d "$t" ]; then dir_fp "$t"
  elif [ -f "$t" ]; then fp=$(say "$t" | file_fps); say "${fp:-unreadable}"; fi
}

# A source-table path as d or f and its path relative to the project ("" for the project itself),
# separated by $US; nothing when it lies outside the project or no longer exists.
project_rel() {
  t=$(source_target "$1")
  if [ -d "$t" ]; then real=$(cd "$t" && pwd -P) || return 0; kind=d
  elif [ -e "$t" ]; then real=$(cd "$(dirname "$t")" && pwd -P)/${t##*/} || return 0; kind=f
  else return 0; fi
  case "$1" in */) kind=d ;; esac
  case "$real" in
    "$PROJECT_REAL") say "d$US" ;;
    "$PROJECT_REAL"/*) say "$kind$US${real#"$PROJECT_REAL"/}" ;;
  esac
}

instruction_names() { sed -n 's/^instruction-files: //p' "$SRC/templates/context.md"; }
root_names() { sed -n 's/^root-sources: //p' "$SRC/templates/context.md"; }

# Every source intake reads (templates/context.md, Intake step 1), one per line; directories end in /.
# Returns 1, printing nothing, when the project cannot be listed in full.
discover_sources() {
  files=$(mktemp) || return 1
  dir_files "$PROJECT" dependencies > "$files" || { rm -f "$files"; return 1; }
  {
    names=$(instruction_names)
    while IFS= read -r f; do
      base=${f##*/}
      for n in $names; do
        case "$n" in
          */) case "/$f" in */"$n"*) say "$f" ;; esac ;;
          */*) case "$f" in "$n"|*/"$n") say "$f" ;; esac ;;
          *) [ "$base" = "$n" ] && say "$f" ;;
        esac
      done
    done < "$files"
    roots=$(root_names)
    # Unquoted, so each * entry expands to the files it matches at the project's top level.
    (cd "$PROJECT" && for f in $roots; do
      case "$f" in
        */) [ -d "$f" ] && say "$f" ;;
        *) [ -f "$f" ] && say "$f" ;;
      esac
    done)
  } | awk '!seen[$0]++'
  rm -f "$files"
}

# Every source discover_sources finds, into the file $1, or stop: a project that cannot be listed in
# full has sources intake and refresh would miss.
discover_into() {
  discover_sources > "$1" ||
    die "cannot list every file in $PROJECT, so its sources cannot all be found; the context map was not written"
}

# Stop before anything is written when intake or refresh will run on a project that cannot be listed
# in full: they would miss its sources.
check_listing() {
  [ "$MODE" = refresh ] || [ ! -f "$PROJECT/.mercury/context.md" ] || return 0
  workspace_init
  dir_files "$PROJECT" dependencies > /dev/null ||
    die "cannot list every file in $PROJECT, so its sources cannot all be found; nothing was changed"
}

new_row() { printf '| %s | %s | never | new |\n' "$1" "$(fingerprint "$1")"; }

# Copy standard input, adding the rows in file $1 after the Sources table's separator line.
insert_rows() {
  R="$1" awk '{ print } /^## / { s = ($0 ~ /^## Sources[ \t]*$/) }
    s && !done && /^[ \t]*\|[- \t|:]*\|[ \t]*$/ { while ((getline line < ENVIRON["R"]) > 0) print line; done = 1 }'
}

write_config() {
  config="$PROJECT/.mercury/config.md"
  if [ ! -f "$config" ]; then
    act cp "$SRC/templates/config.md" "$config"
    say "  wrote $config"
  fi
  [ "$DRY" = 1 ] && return 0
  append_key project "$PROJECT"
  if [ "$MODE" != refresh ] || [ -n "$EXPLICIT_HOSTS" ]; then append_key hosts "$HOSTS"; fi
  [ -n "$QUEUE" ] && append_key queue "$QUEUE"
  [ -n "$QUEUE_READ" ] && append_key queue_read "$QUEUE_READ"
  return 0
}

# Append key: value unless the last line for the key already says it; Mercury never rewrites config.md.
append_key() {
  last=$(awk -v k="$1" 'index($0, k ": ") == 1 { v = substr($0, length(k) + 3) } END { print v }' "$config")
  [ "$last" = "$2" ] || printf '%s: %s\n' "$1" "$2" >> "$config" || die "could not write $config"
}

write_context() {
  map="$PROJECT/.mercury/context.md"
  if [ -f "$map" ]; then
    [ "$MODE" = refresh ] && refresh_context
    return 0
  fi
  found=$(mktemp) || die "could not create a temporary file"
  discover_into "$found"
  [ "$DRY" = 1 ] && { say "would: write $map with $(($(wc -l < "$found"))) sources for the first role to distill"; rm -f "$found"; return 0; }
  rows=$(mktemp) || die "could not create a temporary file"
  while IFS= read -r src; do new_row "$src"; done < "$found" > "$rows"
  rm -f "$found"
  insert_rows "$rows" < "$SRC/templates/context.md" > "$map.tmp.$$" || die "could not write $map"
  mv "$map.tmp.$$" "$map" || die "could not write $map"
  rm -f "$rows"
  say "  wrote $map with its sources; the first role you use distills them"
}

# Mark each Sources row whose source changed or vanished, drop rows already marked removed, and add
# a row for each source no row covers (templates/context.md, Refresh).
refresh_context() {
  awk '/^## / { s = ($0 ~ /^## Sources[ \t]*$/) } s && /^[ \t]*\|[- \t|:]*\|[ \t]*$/ { found = 1 } END { exit !found }' "$map" ||
    die "cannot refresh $map: it has no Sources table (copy the table from templates/context.md)"
  if ! { rows=$(mktemp) && edits=$(mktemp) && rooted=$(mktemp) && found=$(mktemp) && added=$(mktemp); }; then
    die "could not create temporary files"
  fi
  # Each row after the table header: line number, path, fingerprint, last read and state.
  awk -v us="$US" '/^## / { s = ($0 ~ /^## Sources[ \t]*$/); h = 0; next }
    s && /^[ \t]*\|/ && !/^[ \t]*\|[- \t|:]*\|[ \t]*$/ {
      if (!h++) next
      line = $0; sub(/^[ \t]*\|/, "", line); sub(/\|[ \t]*$/, "", line)
      n = split(line, c, "|"); out = NR
      for (i = 1; i <= 4; i++) { v = (i <= n) ? c[i] : ""; gsub(/^[ \t`]+|[ \t`]+$/, "", v); out = out us v }
      print out }' "$map" > "$rows"
  while IFS="$US" read -r n p fp last st; do
    case "$p" in ""|"<"*">") continue ;; esac
    if [ "$st" = removed ]; then printf '%s%sDROP\n' "$n" "$US" >> "$edits"; continue; fi
    project_rel "$p" >> "$rooted"
    case "$p" in *://*) continue ;; esac
    [ "$st" = unreachable ] && continue
    cur=$(fingerprint "$p")
    if [ -z "$cur" ]; then mark=removed
    elif [ "$st" = read ] && { [ "$cur" != "$fp" ] || [ "$cur" = dir:unreadable ]; }; then mark=changed
    else continue; fi
    printf '%s%s| %s | %s | %s | %s |\n' "$n" "$US" "$p" "$fp" "$last" "$mark" >> "$edits"
  done < "$rows"
  discover_into "$found"
  R="$rooted" awk -F "$US" 'FILENAME == ENVIRON["R"] { kind[++n] = $1; rel[n] = $2; next }
    { s = $0; sub(/\/$/, "", s)
      for (i = 1; i <= n; i++) if (rel[i] == s || (kind[i] == "d" && (rel[i] == "" || index(s, rel[i] "/") == 1))) next
      print }' "$rooted" "$found" | while IFS= read -r src; do new_row "$src"; done > "$added"
  summary="$(grep -c 'changed |$' "$edits") changed, $(grep -c 'removed |$' "$edits") removed, $(grep -c 'DROP$' "$edits") dropped, $(($(wc -l < "$added")))"
  if [ "$DRY" = 1 ]; then say "would: mark $summary new in $map"
  else
    E="$edits" A="$added" awk -v us="$US" '
      BEGIN { while ((getline e < ENVIRON["E"]) > 0) { k = index(e, us); edit[substr(e, 1, k - 1)] = substr(e, k + 1) } }
      FNR in edit { if (edit[FNR] != "DROP") print edit[FNR]; next }
      { print }
      /^## / { s = ($0 ~ /^## Sources[ \t]*$/) }
      s && !done && /^[ \t]*\|[- \t|:]*\|[ \t]*$/ { while ((getline line < ENVIRON["A"]) > 0) print line; done = 1 }' "$map" > "$map.tmp.$$" ||
      die "could not write $map"
    mv "$map.tmp.$$" "$map" || die "could not write $map"
    say "  marked $summary new in $map; the next role re-reads exactly those"
  fi
  rm -f "$rows" "$edits" "$rooted" "$found" "$added"
}

setup_workspace() {
  workspace_init
  act mkdir -p "$PROJECT/.mercury"
  if [ ! -f "$PROJECT/.mercury/.gitignore" ]; then
    if [ "$DRY" = 0 ]; then printf 'work/\nqueue.md\n' > "$PROJECT/.mercury/.gitignore" || die "could not write $PROJECT/.mercury/.gitignore"; fi
    say "  wrote $PROJECT/.mercury/.gitignore (ledgers and ticket titles stay local)"
  fi
  write_config
  write_context
}

check_authority() {
  for pair in $(printf '%s' "$AUTHORITY" | tr ',' ' '); do
    action=${pair%%=*}; value=${pair#*=}
    case " $ACTIONS " in *" $action "*) ;; *) die "unknown action $action (one of: $ACTIONS)" ;; esac
    case "$value" in ask|allowed|never) ;; *) die "action $action needs ask, allowed or never" ;; esac
  done
}

write_authority() {
  [ -n "$AUTHORITY" ] || return 0
  file="$HOME_DIR/.mercury/authority.md"
  act mkdir -p "$HOME_DIR/.mercury"
  if [ ! -f "$file" ] && [ "$DRY" = 0 ]; then
    printf '# What Mercury may do without asking. One line per answer: <action>: <ask|allowed|never> [for <project>].\n# The most specific line wins, then the last. Mercury only appends here.\n' > "$file" ||
      die "could not write $file"
  fi
  for pair in $(printf '%s' "$AUTHORITY" | tr ',' ' '); do
    action=${pair%%=*}; value=${pair#*=}
    if [ "$SCOPE" = project ]; then line="$action: $value for $PROJECT"; else line="$action: $value"; fi
    if [ "$DRY" = 1 ]; then say "would: append '$line' to $file"; else printf '%s\n' "$line" >> "$file" || die "could not write $file"; fi
  done
  say "  recorded standing authority in $file"
}

# --- Questions for a person at a terminal ---------------------------------------------------------

ask() { printf '%s ' "$1" >&2; read -r answer || answer=""; [ -n "$answer" ] || answer=$2; printf '%s' "$answer"; }

# Answers as a person types them: any letter case, spaces after commas, a quoted path, a path under ~.
lower_list() { printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | tr -d ' \t'; }
folder() {
  f=$1
  case "$f" in \"*\") f=${f#\"}; f=${f%\"} ;; \'*\') f=${f#\'}; f=${f%\'} ;; esac
  # shellcheck disable=SC2088 # these patterns match a literal ~ the person typed
  case "$f" in "~") f=$HOME_DIR ;; "~/"*) f="$HOME_DIR/${f#??}" ;; esac
  say "$f"
}

questions() {
  say "Mercury setup: four questions. Press Enter to take the suggestion in brackets."
  here=$(pwd); case "$here/" in "$PKG"/*) here="" ;; esac
  where=$(ask "1. Install for which project folder? Type 'all' for every project of yours.${here:+ [$here]}" "$here")
  [ -n "$where" ] || die "no project folder given"
  if [ "$where" = all ]; then SCOPE=user; else SCOPE=project; PROJECT=$where; fi
  suggestion=$(saved_hosts); [ -n "$suggestion" ] || suggestion=$(detect_hosts)
  HOSTS=$(ask "2. Which assistants? copilot, claude, agents (Codex, Cursor, Gemini and others), kiro, cline [$suggestion]" "$suggestion")
  q=$(ask "3. Do you work a queue of tickets or issues? If so, where (for GitHub: owner/repo and a label)? [no]" "no")
  [ "$q" = no ] || QUEUE=$q
  say "4. What may Mercury do without asking you first? Everything else it asks about."
  say "   Actions: $ACTIONS"
  AUTHORITY=$(ask "   Type action=allowed pairs separated by commas, or Enter for none: []" "")
}

# --- Main ----------------------------------------------------------------------------------------

if [ "$SAW_FLAG" = 0 ] && [ "$ASK" = 1 ] && [ -t 0 ]; then questions; fi
HOSTS=$(lower_list "$HOSTS"); AUTHORITY=$(lower_list "$AUTHORITY")
[ -z "$PROJECT" ] || PROJECT=$(folder "$PROJECT")
[ -n "$SCOPE" ] || SCOPE=project
if [ "$SCOPE" = project ]; then
  [ -n "$PROJECT" ] || PROJECT=$(pwd)
  [ -d "$PROJECT" ] || die "no such project folder: $PROJECT"
  PROJECT=$(cd "$PROJECT" && pwd)
  case "$PROJECT/" in "$PKG"/*) die "$PROJECT is the Mercury package itself: name your project with --project DIR, or use --user" ;; esac
fi
EXPLICIT_HOSTS=$HOSTS
[ -n "$HOSTS" ] || HOSTS=$(saved_hosts)
[ -n "$HOSTS" ] || HOSTS=$(detect_hosts)
check_hosts
check_authority
OTHER=user; [ "$SCOPE" = user ] && OTHER=project
ALL_HOSTS=copilot,claude,agents,kiro,cline

say "Mercury $(cat "$SRC/VERSION"): $MODE at $SCOPE scope${PROJECT:+ for $PROJECT}, hosts $HOSTS"
case "$MODE" in
  install|update)
    roots_file=$(mktemp) || die "could not create a temporary file"
    selected_roots "$SCOPE" "$HOSTS" > "$roots_file" || die "could not write $roots_file"
    check_roots "$roots_file" install
    [ "$SCOPE" = project ] && check_listing
    while IFS= read -r root; do install_root "$root"; done < "$roots_file"
    rm -f "$roots_file"
    if [ "$POINTER" = 1 ] && [ "$SCOPE" = project ]; then
      pointer_files | while IFS= read -r f; do add_pointer "$f"; done || exit 1
    fi
    [ "$SCOPE" = project ] && setup_workspace
    write_authority
    [ "$SCOPE" = project ] && warn_skew "$OTHER"
    if [ "$MODE" = update ]; then
      for d in ${PROJECT:+"$PROJECT/.mercury/protocol"} "$HOME_DIR/.mercury/protocol"; do
        [ -d "$d" ] && say "  protocol additions exist in $d: ask the protocol-doctor to reconcile them with this version"
      done
    fi
    case ",$HOSTS," in *,copilot,*) [ "$SCOPE" = project ] && say "  for the Copilot cloud agent, commit .github/skills/mercury: it reads only repository skills" ;; esac
    ;;
  refresh)
    [ "$SCOPE" = project ] || die "--refresh-context needs a project"
    check_listing
    setup_workspace ;;
  uninstall)
    roots_file=$(mktemp) || die "could not create a temporary file"
    selected_roots "$SCOPE" "${EXPLICIT_HOSTS:-$ALL_HOSTS}" > "$roots_file" || die "could not write $roots_file"
    check_roots "$roots_file" uninstall
    while IFS= read -r root; do uninstall_root "$root"; done < "$roots_file"
    rm -f "$roots_file"
    if [ "$SCOPE" = project ]; then
      for f in "$PROJECT/.github/copilot-instructions.md" "$PROJECT/AGENTS.md"; do remove_pointer "$f"; done
      [ -d "$PROJECT/.mercury" ] && say "  left $PROJECT/.mercury (your context, notes and records); delete it if you no longer want them"
    fi ;;
esac
say "done"
