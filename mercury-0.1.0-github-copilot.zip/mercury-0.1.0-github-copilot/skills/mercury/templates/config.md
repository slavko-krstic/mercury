# Mercury configuration
# One `key: value` per line; `#` starts a comment, and a value in angle brackets is unset. Mercury
# only appends: the last line for a key wins, and nothing in Mercury rewrites this file. Tidy it by
# hand, while no Mercury session is running. Required: project and hosts, and queue and queue_read
# for the on-call roles.

mercury: 1
project: <the project directory>
hosts: <the assistants Mercury is installed for, comma-separated>
# For the on-call roles: where work items live, and the exact read that returns every open item.
# Example: queue_read: gh issue list --repo <owner>/<repo> --label <label> --state open --limit 1000 --json number,title,updatedAt
# Jira: queue_read: python3 <skill folder>/scripts/jira.py search --site <site> --jql '<query>' (see jira.md)
queue: <a repository and label, or a ticket system's search address>
queue_read: <the exact command or tool call>
# Optional
verify_window: <how long a fix must hold; default the alert's own window, else 24h>
sources: <extra context sources for intake: wiki pages, dashboards, other repositories>
lessons: on
token_budget: <tokens per objective>

# Standing authority is never kept here, because a repository file can arrive in a clone. It lives
# in the user's own ~/.mercury/authority.md (on Windows %USERPROFILE%\.mercury\authority.md):
#
#   <action>: <ask|allowed|never>
#   <action>: <ask|allowed|never> for <project path>
#
# Actions: push, open_pull_request, comment, change_ticket, close_ticket, message_people, deploy,
# change_production. A line naming a project path is more specific than one without; the most
# specific line wins, and among equally specific lines the last one wins. A missing action means
# ask. Only the installer and the protocol-doctor (at the user's request) append to it; nothing in
# Mercury rewrites it.
#
# A grant names actions, never "everything", and reaches only the objective's own branch, pull
# request, tickets and the targets its ledger names. push never forces and never targets the default
# branch; close_ticket applies only at REMEDIATION_SUCCESSFUL. The user's words in a session may
# widen or narrow a grant for that session only. Reread the file before every external write, so a
# removed grant takes effect at once. A host that cannot read the user's home has no grants and asks.
