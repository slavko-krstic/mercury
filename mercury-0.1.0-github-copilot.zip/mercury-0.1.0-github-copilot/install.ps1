# Mercury installer for Windows PowerShell 5.1 and PowerShell 7. Needs no network, no administrator
# rights and no Python. Copies skills\mercury into each selected assistant's skill root as a real copy,
# with an ownership manifest, and sets up the project's .mercury folder.
#
#   powershell -ExecutionPolicy Bypass -File install.ps1                 ask four questions, then install
#   powershell -ExecutionPolicy Bypass -File install.ps1 --project DIR   install for one project
#   powershell -ExecutionPolicy Bypass -File install.ps1 --user          install for every project of yours
#
# Options (either --name or -Name): --hosts copilot,claude,agents,kiro,cline  --queue TEXT
#   --queue-read COMMAND  --authority ACTION=allowed|never|ask[,...]  --pointer  --update
#   --refresh-context  --uninstall  --dry-run  --yes (no questions)  --help
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

$Argv = @($args)
$Pkg = Split-Path -Parent $MyInvocation.MyCommand.Path
$Src = Join-Path $Pkg 'skills/mercury'
$HomeDir = [Environment]::GetFolderPath('UserProfile')
$Utf8 = New-Object System.Text.UTF8Encoding $false
$Actions = @('push', 'open_pull_request', 'comment', 'change_ticket', 'close_ticket', 'message_people', 'deploy', 'change_production')
$MarkBegin = '<!-- mercury:begin -->'
$MarkEnd = '<!-- mercury:end -->'
$Scope = ''; $Project = ''; $Hosts = ''; $Queue = ''; $QueueRead = ''; $Authority = ''
$Pointer = $false; $Mode = 'install'; $Dry = $false; $Ask = $true; $SawFlag = $false

function Say([string]$Text) { Write-Output $Text }
function Fail([string]$Text) { [Console]::Error.WriteLine("mercury install: $Text"); exit 1 }

function Next {
    if ($script:i + 1 -ge $script:Argv.Count) { Fail "$($script:Argv[$script:i]) needs a value" }
    $script:i++
    return [string]$script:Argv[$script:i]
}
$i = 0
while ($i -lt $Argv.Count) {
    $SawFlag = $true
    $name = ([string]$Argv[$i]).TrimStart('-').ToLowerInvariant().Replace('-', '')
    switch ($name) {
        'project' { $Scope = 'project'; $Project = Next }
        'user' { $Scope = 'user' }
        'hosts' { $Hosts = Next }
        'queue' { $Queue = Next }
        'queueread' { $QueueRead = Next }
        'authority' { $Authority = Next }
        'pointer' { $Pointer = $true }
        'update' { $Mode = 'update' }
        'refreshcontext' { $Mode = 'refresh' }
        'uninstall' { $Mode = 'uninstall' }
        'dryrun' { $Dry = $true }
        'yes' { $Ask = $false }
        { $_ -in @('help', 'h') } { Get-Content -LiteralPath $MyInvocation.MyCommand.Path -TotalCount 11 | ForEach-Object { $_ -replace '^# ?', '' }; exit 0 }
        default { Fail "unknown option $($Argv[$i]) (try --help)" }
    }
    $i++
}
if (-not (Test-Path -LiteralPath (Join-Path $Src 'SKILL.md'))) { Fail "run this from the Mercury package: $Src/SKILL.md is missing" }

# Runs git and returns its standard output; stderr never becomes an error record, so a failing git
# call cannot stop the script under ErrorActionPreference Stop on Windows PowerShell 5.1.
function Run-Git {
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { $out = & git @args 2>$null; $script:GitExit = $LASTEXITCODE }
    finally { $ErrorActionPreference = $saved }
    return $out
}

function Hash-File([string]$Path) { (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant() }

function Hash-Text([string]$Text) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = $sha.ComputeHash($Utf8.GetBytes($Text))
    return (($bytes | ForEach-Object { $_.ToString('x2') }) -join '')
}

function Write-Text([string]$Path, [string]$Text) { if (-not $Dry) { [System.IO.File]::WriteAllText($Path, $Text, $Utf8) } }
# Replace a file whole: an interruption leaves either the old bytes or the new ones.
function Replace-Text([string]$Path, [string]$Text) {
    if ($Dry) { return }
    $tmp = "$Path.tmp.$PID"
    [System.IO.File]::WriteAllText($tmp, $Text, $Utf8)
    if (Test-Path -LiteralPath $Path) { [System.IO.File]::Replace($tmp, $Path, [NullString]::Value) }
    else { [System.IO.File]::Move($tmp, $Path) }
}
function Add-Text([string]$Path, [string]$Text) { if (-not $Dry) { [System.IO.File]::AppendAllText($Path, $Text, $Utf8) } }
function New-Dir([string]$Path) { if (-not $Dry -and -not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } }
function Copy-File([string]$From, [string]$To) {
    if ($Dry) { Say "would: copy $From to $To"; return }
    New-Dir (Split-Path -Parent $To)
    Copy-Item -LiteralPath $From -Destination $To -Force
}
function Has-Command([string]$Name) { return [bool](Get-Command $Name -ErrorAction SilentlyContinue) }

function Detect-Hosts {
    $found = @()
    if ((Test-Path (Join-Path $HomeDir '.copilot')) -or (Has-Command 'copilot') -or (Has-Command 'code')) { $found += 'copilot' }
    if ((Test-Path (Join-Path $HomeDir '.claude')) -or (Has-Command 'claude')) { $found += 'claude' }
    $agentDirs = @('.codex', '.cursor', '.gemini', '.agents') | Where-Object { Test-Path (Join-Path $HomeDir $_) }
    if ($agentDirs -or (Has-Command 'codex') -or (Has-Command 'gemini') -or (Has-Command 'cursor')) { $found += 'agents' }
    if ((Test-Path (Join-Path $HomeDir '.kiro')) -or (Has-Command 'kiro')) { $found += 'kiro' }
    if ($found.Count -eq 0) { $found = @('copilot', 'claude', 'agents') }
    return ($found -join ',')
}

# The skill roots one host reads, by scope (design section 14).
function Root-For([string]$HostName, [string]$ForScope) {
    $base = if ($ForScope -eq 'project') { $Project } else { $HomeDir }
    $rel = switch ("${HostName}:${ForScope}") {
        'copilot:project' { '.github/skills' } 'copilot:user' { '.copilot/skills' }
        'claude:project' { '.claude/skills' } 'claude:user' { '.claude/skills' }
        'cline:project' { '.claude/skills' } 'cline:user' { '.cline/skills' }
        'agents:project' { '.agents/skills' } 'agents:user' { '.agents/skills' }
        'kiro:project' { '.kiro/skills' } 'kiro:user' { '.kiro/skills' }
        default { Fail "unknown host $HostName (use copilot, claude, agents, kiro or cline)" }
    }
    return (Join-Path $base $rel)
}

# The hosts the last install chose: config.md's last hosts value for a project, and for a user
# install every host whose skill root holds a manifest.
function Saved-Hosts {
    if ($Scope -eq 'project') {
        $config = Join-Path $Project '.mercury/config.md'
        if (-not (Test-Path -LiteralPath $config)) { return '' }
        $last = ''
        foreach ($line in [System.IO.File]::ReadAllLines($config)) { if ($line.StartsWith('hosts: ')) { $last = $line.Substring(7) } }
        if ($last.StartsWith('<')) { return '' }
        return $last
    }
    $found = @()
    foreach ($h in @('copilot', 'claude', 'agents', 'kiro', 'cline')) {
        if (Test-Path -LiteralPath (Join-Path (Root-For $h 'user') 'mercury/.mercury-manifest')) { $found += $h }
    }
    return ($found -join ',')
}

# Whether a folder is the Mercury package or inside it, which is never a project.
function Inside-Package([string]$Path) {
    $root = [IO.Path]::GetFullPath($Pkg).TrimEnd('\', '/')
    $full = [IO.Path]::GetFullPath($Path).TrimEnd('\', '/')
    return ($full.Equals($root, $PathCompare) -or $full.StartsWith($root + [IO.Path]::DirectorySeparatorChar, $PathCompare))
}

function Selected-Roots([string]$ForScope, [string]$HostList) {
    $roots = @()
    foreach ($h in ($HostList -split ',')) { if ($h.Trim()) { $roots += (Root-For $h.Trim() $ForScope) } }
    return ($roots | Sort-Object -Unique)
}

function Package-Files {
    $prefix = (Resolve-Path -LiteralPath $Src).Path.TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar
    [string[]]$files = Get-ChildItem -LiteralPath $Src -Recurse -File -Force |
        Where-Object { $_.Name -notlike '*.pyc' -and $_.FullName -notmatch '[\\/]__pycache__[\\/]' } |
        ForEach-Object { $_.FullName.Substring($prefix.Length).Replace('\', '/') }
    [Array]::Sort($files, [StringComparer]::Ordinal)
    return $files
}

function Read-Manifest([string]$Path) {
    $map = @{}
    if (Test-Path -LiteralPath $Path) {
        foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
            if ($line.Length -gt 66) { $map[$line.Substring(66)] = $line.Substring(0, 64) }
        }
    }
    return $map
}

# A path inside the skill folder: relative, with no empty, . or .. part, no backslash and no colon,
# so it cannot leave the folder or name a drive or a stream.
function Confined-Rel([string]$Rel) {
    if (-not $Rel -or $Rel.StartsWith('/') -or $Rel.EndsWith('/') -or $Rel.Contains('\') -or $Rel.Contains(':')) { return $false }
    foreach ($part in $Rel.Split('/')) { if ($part -eq '' -or $part -eq '.' -or $part -eq '..') { return $false } }
    return $true
}

# Refuse a skill folder that is a link or holds one, and a manifest line that is not a digest and a
# confined path. Either would let an install, update or uninstall write or delete a file outside the
# skill.
function Check-SkillFolder([string]$Dest, [string]$Manifest) {
    if (Test-Path -LiteralPath $Dest) {
        $pending = New-Object System.Collections.Generic.Stack[string]
        $pending.Push($Dest)
        while ($pending.Count -gt 0) {
            $item = Get-Item -LiteralPath $pending.Pop() -Force
            # A symbolic link or junction redirects a path; other reparse points, such as a synced
            # folder's placeholders, do not.
            if ($item.LinkType -eq 'SymbolicLink' -or $item.LinkType -eq 'Junction') {
                Fail "$($item.FullName) is a link inside the Mercury skill folder; remove it and run again; nothing was changed"
            }
            if ($item.PSIsContainer) { foreach ($child in @(Get-ChildItem -LiteralPath $item.FullName -Force)) { $pending.Push($child.FullName) } }
        }
    }
    if (-not (Test-Path -LiteralPath $Manifest)) { return }
    $n = 0
    foreach ($line in [System.IO.File]::ReadAllLines($Manifest)) {
        $n++
        if ($line -cnotmatch '^[0-9a-f]{64}  .') { Fail "$Manifest line $n is not a manifest line; nothing was changed" }
        $rel = $line.Substring(66)
        if (-not (Confined-Rel $rel)) { Fail "$Manifest names $rel, which is outside $Dest; nothing was changed" }
    }
}

# Check every skill folder a run will change before it changes any (Check-SkillFolder), so a refusal
# leaves every host's copy as it was. Uninstall leaves a folder without a manifest alone, so for it
# ($ManifestOnly) only a folder with one is checked.
function Check-Roots([string[]]$Roots, [bool]$ManifestOnly) {
    foreach ($root in $Roots) {
        $dest = Join-Path $root 'mercury'
        $manifest = Join-Path $dest '.mercury-manifest'
        if ($ManifestOnly -and -not (Test-Path -LiteralPath $manifest)) { continue }
        Check-SkillFolder $dest $manifest
    }
}

function Install-Root([string]$Root) {
    $dest = Join-Path $Root 'mercury'
    $manifest = Join-Path $dest '.mercury-manifest'
    $hadManifest = Test-Path -LiteralPath $manifest
    if ((Test-Path -LiteralPath $dest) -and -not $hadManifest) { Say "  $dest has no manifest: adopting files that match this package" }
    $old = Read-Manifest $manifest
    New-Dir $dest
    $lines = New-Object System.Text.StringBuilder
    $files = Package-Files
    foreach ($rel in $files) {
        $from = Join-Path $Src $rel
        $new = Hash-File $from
        $target = Join-Path $dest $rel
        if (Test-Path -LiteralPath $target) {
            $cur = Hash-File $target
            if ($cur -eq $new) { }
            elseif ($hadManifest -and $old.ContainsKey($rel) -and $cur -eq $old[$rel]) { Copy-File $from $target }
            else { Copy-File $from "$target.new"; Say "  kept your edit of $target; the new version is $target.new" }
        }
        else { Copy-File $from $target }
        [void]$lines.Append("$new  $rel`n")
    }
    if ($hadManifest) {
        foreach ($rel in $old.Keys) {
            if ($files -contains $rel) { continue }
            $target = Join-Path $dest $rel
            if (-not (Test-Path -LiteralPath $target)) { continue }
            if ((Hash-File $target) -eq $old[$rel]) { if (-not $Dry) { Remove-Item -LiteralPath $target -Force } }
            else { Say "  $target is no longer part of Mercury but you edited it, so it stays" }
        }
    }
    if (-not $Dry) {
        Replace-Text $manifest $lines.ToString()
    }
    Say "  installed $dest"
}

function Uninstall-Root([string]$Root) {
    $dest = Join-Path $Root 'mercury'
    $manifest = Join-Path $dest '.mercury-manifest'
    if (-not (Test-Path -LiteralPath $manifest)) {
        if (Test-Path -LiteralPath $dest) { Say "  $dest has no manifest, so nothing there is known to be Mercury's; left alone" }
        return
    }
    $old = Read-Manifest $manifest
    foreach ($rel in $old.Keys) {
        $target = Join-Path $dest $rel
        if (-not (Test-Path -LiteralPath $target)) { continue }
        if ((Hash-File $target) -eq $old[$rel]) { if (-not $Dry) { Remove-Item -LiteralPath $target -Force } }
        else { Say "  kept ${target}: you edited it" }
    }
    if (-not $Dry) {
        Remove-Item -LiteralPath $manifest -Force
        Get-ChildItem -LiteralPath $dest -Recurse -Directory -Force | Sort-Object { $_.FullName.Length } -Descending |
            Where-Object { -not (Get-ChildItem -LiteralPath $_.FullName -Force) } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force }
        if (-not (Get-ChildItem -LiteralPath $dest -Force)) { Remove-Item -LiteralPath $dest -Force }
    }
    if (Test-Path -LiteralPath $dest) { Say "  $dest still holds files you changed or added" } else { Say "  removed $dest" }
}

function Pointer-Files {
    $files = @()
    if ((",$Hosts,") -match ',copilot,') { $files += (Join-Path $Project '.github/copilot-instructions.md') }
    if ((",$Hosts,") -match ',(agents|claude|kiro|cline),') { $files += (Join-Path $Project 'AGENTS.md') }
    return $files
}

function Add-Pointer([string]$File) {
    if ((Test-Path -LiteralPath $File) -and ((Get-Content -LiteralPath $File -Raw) -match [regex]::Escape($MarkBegin))) { return }
    New-Dir (Split-Path -Parent $File)
    $lead = ''
    if ((Test-Path -LiteralPath $File) -and (Get-Item -LiteralPath $File).Length -gt 0) { $lead = "`n" }
    Add-Text $File "$lead$MarkBegin`nUse the mercury skill for authoring, review, incidents, ticket queues and research here: say `"use Mercury`".`n$MarkEnd`n"
    Say "  added the Mercury pointer to $File"
}

# Remove each pointer block whose begin and end markers pair up; a file where one has lost a marker
# line is left as it is, so no line of the user's goes with it.
function Remove-Pointer([string]$File) {
    if (-not (Test-Path -LiteralPath $File)) { return }
    $lines = [System.IO.File]::ReadAllLines($File)
    if (-not ($lines -ccontains $MarkBegin)) { return }
    $open = $false; $bad = $false
    foreach ($line in $lines) {
        if ($line -ceq $MarkBegin) { if ($open) { $bad = $true }; $open = $true }
        elseif ($line -ceq $MarkEnd) { if (-not $open) { $bad = $true }; $open = $false }
    }
    if ($bad -or $open) { Say "  left $File as it is: a Mercury pointer there has lost a marker line, so remove that block by hand"; return }
    $keep = New-Object System.Collections.Generic.List[string]
    $skip = $false
    foreach ($line in $lines) {
        if ($line -ceq $MarkBegin) {
            $skip = $true
            if ($keep.Count -gt 0 -and $keep[$keep.Count - 1] -eq '') { $keep.RemoveAt($keep.Count - 1) }
            continue
        }
        if ($line -ceq $MarkEnd) { $skip = $false; continue }
        if (-not $skip) { $keep.Add($line) }
    }
    $text = ($keep -join "`n")
    if ($keep.Count -gt 0) { $text += "`n" }
    Replace-Text $File $text
    Say "  removed the Mercury pointer from $File"
}

# --- Workspace state ------------------------------------------------------------------------------
# Fingerprints follow templates/context.md, the one definition scripts/check.py computes too.

$script:GitTop = ''
$IsWindowsHost = [IO.Path]::DirectorySeparatorChar -eq '\'
$PathCompare = if ($IsWindowsHost) { [StringComparison]::OrdinalIgnoreCase } else { [StringComparison]::Ordinal }
$Separator = '^[ \t]*\|[- \t|:]*\|[ \t]*$'

# Run once, before any fingerprint.
function Workspace-Init {
    $script:GitTop = ''
    if (Has-Command 'git') {
        $out = Run-Git -C $Project rev-parse --show-toplevel
        if ($script:GitExit -eq 0) { $script:GitTop = "$out".Trim() }
    }
}
function In-Git { return [bool]$script:GitTop }

# A source-table path made absolute: it is relative to the project, absolute, or under ~/.
function Source-Target([string]$Path) {
    if ($Path -eq '~') { $t = $HomeDir }
    elseif ($Path.StartsWith('~/') -or $Path.StartsWith('~\')) { $t = Join-Path $HomeDir $Path.Substring(2) }
    elseif ([IO.Path]::IsPathRooted($Path)) { $t = $Path }
    else { $t = Join-Path $Project $Path }
    $trimmed = $t.TrimEnd('/', '\')
    if ($trimmed) { return $trimmed }
    return $t
}

# Whether git, run in a directory, reports the project's repository; a nested repository, or none,
# is somewhere else.
function In-Project-Repo([string]$Dir) {
    if (-not (In-Git)) { return $false }
    $out = Run-Git -C $Dir rev-parse --show-toplevel
    return ($script:GitExit -eq 0 -and "$out".Trim() -eq $script:GitTop)
}

# Every file under a directory, without entering the skipped directories or linked directories;
# a directory it may not read is skipped, as scripts/check.py's walk skips it.
function Walk-Files([string]$Dir, [string[]]$Skip) {
    $stack = New-Object System.Collections.Generic.Stack[string]
    $stack.Push($Dir)
    while ($stack.Count -gt 0) {
        foreach ($item in @(Get-ChildItem -LiteralPath $stack.Pop() -Force -ErrorAction Stop)) {
            if (-not $item.PSIsContainer) { $item.FullName }
            elseif ($Skip -cnotcontains $item.Name -and $item.LinkType -ne 'SymbolicLink') { $stack.Push($item.FullName) }
        }
    }
}

# The existing files under a directory, relative to it with forward slashes, leaving out every file
# in a .git or .mercury directory below it, and in a node_modules directory too when asked. A listing
# that fails is not an empty one: when git fails or warns, or the walk meets a folder it cannot open,
# this says the first error on standard error and throws.
function Dir-Files([string]$Dir, [bool]$SkipDependencies = $false) {
    $skip = @('.git', '.mercury')
    if ($SkipDependencies) { $skip += 'node_modules' }
    $pattern = '(^|/)(' + (($skip | ForEach-Object { [regex]::Escape($_) }) -join '|') + ')/'
    if (In-Project-Repo $Dir) {
        $errors = [IO.Path]::GetTempFileName()
        $saved = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try { $out = & git -C $Dir ls-files -z --cached --others --exclude-standard 2> $errors; $code = $LASTEXITCODE }
        finally { $ErrorActionPreference = $saved }
        $warned = (Get-Item -LiteralPath $errors).Length -gt 0
        $first = @(Get-Content -LiteralPath $errors -TotalCount 1)
        Remove-Item -LiteralPath $errors -Force
        if ($code -ne 0 -or $warned) {
            if ($first.Count) { [Console]::Error.WriteLine("  $($first[0])") }
            throw "cannot list every file under $Dir"
        }
        $names = (@($out) -join "`n").Split([char]0)
    }
    else {
        $root = [IO.Path]::GetFullPath($Dir).TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar
        try { $names = @(Walk-Files $Dir $skip | ForEach-Object { $_.Substring($root.Length).Replace('\', '/') }) }
        catch { [Console]::Error.WriteLine("  $($_.Exception.Message)"); throw "cannot list every file under $Dir" }
    }
    return @($names | Where-Object { $_ -and $_ -cnotmatch $pattern -and (Test-Path -LiteralPath (Join-Path $Dir $_) -PathType Leaf) })
}

# One fingerprint per path, in order; a path that cannot be read gets none.
function File-Fps([string[]]$Paths) {
    $prints = New-Object System.Collections.Generic.List[string]
    if (In-Git) {
        for ($k = 0; $k -lt $Paths.Count; $k += 100) {
            [string[]]$chunk = $Paths[$k..([Math]::Min($k + 99, $Paths.Count - 1))]
            foreach ($h in @(Run-Git -C $Project hash-object '--' @chunk)) { if ("$h".Trim()) { $prints.Add('git:' + "$h".Trim()) } }
        }
    }
    else {
        foreach ($p in $Paths) {
            try {
                $item = Get-Item -LiteralPath $p -Force
                if ($item.LinkType -and $item.PSObject.Methods['ResolveLinkTarget']) { $target = $item.ResolveLinkTarget($true); if ($target) { $item = $target } }
                $prints.Add("stat:$($item.Length):$([DateTimeOffset]::new($item.LastWriteTimeUtc).ToUnixTimeSeconds())")
            }
            catch { }
        }
    }
    return $prints
}

# dir:<SHA-256 of one "<fingerprint> <path>\n" line per file, sorted by its path relative to the directory>.
function Dir-Fp([string]$Dir) {
    try { [string[]]$names = @(Dir-Files $Dir) }
    catch {
        [Console]::Error.WriteLine("  cannot list every file under $Dir, so its fingerprint is dir:unreadable")
        return 'dir:unreadable'
    }
    [Array]::Sort($names, [StringComparer]::Ordinal)
    [string[]]$paths = @($names | ForEach-Object { Join-Path $Dir $_ })
    $prints = @(File-Fps $paths)
    if ($prints.Count -ne $names.Count) {
        [Console]::Error.WriteLine("  cannot read every file under $Dir, so its fingerprint is dir:unreadable")
        return 'dir:unreadable'
    }
    $text = New-Object System.Text.StringBuilder
    for ($k = 0; $k -lt $names.Count; $k++) { [void]$text.Append("$($prints[$k]) $($names[$k])`n") }
    return 'dir:' + (Hash-Text $text.ToString())
}

# A source's fingerprint, or '' when it no longer exists.
function Fingerprint([string]$Path) {
    $t = Source-Target $Path
    if (Test-Path -LiteralPath $t -PathType Container) { return (Dir-Fp $t) }
    if (Test-Path -LiteralPath $t -PathType Leaf) {
        $fp = @(File-Fps @($t))
        if ($fp.Count -eq 1) { return $fp[0] }
        return 'unreadable'
    }
    return ''
}

# A source-table path's kind (d or f) and its path relative to the project ('' for the project
# itself); $null when it lies outside the project or no longer exists.
function Project-Rel([string]$Path) {
    $t = Source-Target $Path
    if (Test-Path -LiteralPath $t -PathType Container) { $kind = 'd' } elseif (Test-Path -LiteralPath $t) { $kind = 'f' } else { return $null }
    if ($Path.EndsWith('/')) { $kind = 'd' }
    $full = [IO.Path]::GetFullPath($t).TrimEnd('\', '/')
    $root = [IO.Path]::GetFullPath($Project).TrimEnd('\', '/')
    if ($full.Equals($root, $PathCompare)) { return [pscustomobject]@{ Kind = 'd'; Rel = '' } }
    if ($full.StartsWith($root + [IO.Path]::DirectorySeparatorChar, $PathCompare)) {
        return [pscustomobject]@{ Kind = $kind; Rel = $full.Substring($root.Length + 1).Replace('\', '/') }
    }
    return $null
}

function Is-Covered([string]$Source, [object[]]$Rooted) {
    $s = $Source.TrimEnd('/')
    foreach ($r in $Rooted) {
        if ($r.Rel.Equals($s, $PathCompare)) { return $true }
        if ($r.Kind -eq 'd' -and ($r.Rel -eq '' -or $s.StartsWith($r.Rel + '/', $PathCompare))) { return $true }
    }
    return $false
}

# Every source intake reads (templates/context.md, Intake step 1); directories end in /.
function Discover-Sources {
    $names = ((Get-Content -LiteralPath (Join-Path $Src 'templates/context.md')) | Where-Object { $_ -like 'instruction-files: *' } |
        Select-Object -First 1).Substring(19).Split(' ')
    $found = New-Object System.Collections.Generic.List[string]
    foreach ($f in @(Dir-Files $Project $true)) {
        $base = $f.Split('/')[-1]
        foreach ($n in $names) {
            if ($n.EndsWith('/')) { if (("/$f").Contains("/$n")) { $found.Add($f) } }
            elseif ($n.Contains('/')) { if ($f -ceq $n -or $f.EndsWith("/$n", [StringComparison]::Ordinal)) { $found.Add($f) } }
            elseif ($base -ceq $n) { $found.Add($f) }
        }
    }
    $roots = ((Get-Content -LiteralPath (Join-Path $Src 'templates/context.md')) | Where-Object { $_ -like 'root-sources: *' } |
        Select-Object -First 1).Substring(14).Split(' ')
    foreach ($r in $roots) {
        if (-not $r) { continue }
        if ($r.EndsWith('/')) {
            if (Test-Path -LiteralPath (Join-Path $Project $r.TrimEnd('/')) -PathType Container) { $found.Add($r) }
        }
        elseif ($r.Contains('*')) {
            [string[]]$matched = @(Get-ChildItem -LiteralPath $Project -File -Force | Where-Object { $_.Name -clike $r } | ForEach-Object { $_.Name })
            [Array]::Sort($matched, [StringComparer]::Ordinal)
            foreach ($m in $matched) { $found.Add($m) }
        }
        elseif (Test-Path -LiteralPath (Join-Path $Project $r) -PathType Leaf) { $found.Add($r) }
    }
    $seen = @{}
    return @($found | Where-Object { if ($seen.ContainsKey($_)) { $false } else { $seen[$_] = $true; $true } })
}

function New-Row([string]$Source) { return "| $Source | $(Fingerprint $Source) | never | new |" }

# Every source Discover-Sources finds, or stop: a project that cannot be listed in full has sources
# intake and refresh would miss.
function Discovered {
    try { return @(Discover-Sources) }
    catch { Fail "cannot list every file in $Project, so its sources cannot all be found; the context map was not written" }
}

# Stop before anything is written when intake or refresh will run on a project that cannot be listed
# in full: they would miss its sources.
function Check-Listing {
    if ($Mode -ne 'refresh' -and (Test-Path -LiteralPath (Join-Path $Project '.mercury/context.md'))) { return }
    Workspace-Init
    try { [void](Dir-Files $Project $true) }
    catch { Fail "cannot list every file in $Project, so its sources cannot all be found; nothing was changed" }
}

function Append-Key([string]$Config, [string]$Key, [string]$Value) {
    $last = $null
    foreach ($line in [System.IO.File]::ReadAllLines($Config)) { if ($line.StartsWith("${Key}: ")) { $last = $line.Substring($Key.Length + 2) } }
    if ($last -ne $Value) { Add-Text $Config "${Key}: $Value`n" }
}

function Write-Config {
    $config = Join-Path $Project '.mercury/config.md'
    if (-not (Test-Path -LiteralPath $config)) { Copy-File (Join-Path $Src 'templates/config.md') $config; Say "  wrote $config" }
    if ($Dry) { return }
    Append-Key $config 'project' $Project
    if ($Mode -ne 'refresh' -or $ExplicitHosts) { Append-Key $config 'hosts' $Hosts }
    if ($Queue) { Append-Key $config 'queue' $Queue }
    if ($QueueRead) { Append-Key $config 'queue_read' $QueueRead }
}

# The lines with the given rows added after the Sources table's separator line.
function Insert-Rows([string[]]$Lines, [string[]]$Rows) {
    $out = New-Object System.Collections.Generic.List[string]
    $inSources = $false; $done = $false
    foreach ($line in $Lines) {
        $out.Add($line)
        if ($line.StartsWith('## ')) { $inSources = $line -cmatch '^## Sources[ \t]*$' }
        if ($inSources -and -not $done -and $line -cmatch $Separator) { foreach ($r in $Rows) { $out.Add($r) }; $done = $true }
    }
    return $out
}

function Write-Context {
    $map = Join-Path $Project '.mercury/context.md'
    if (Test-Path -LiteralPath $map) { if ($Mode -eq 'refresh') { Refresh-Context $map }; return }
    [string[]]$sources = @(Discovered)
    if ($Dry) { Say "would: write $map with $($sources.Count) sources for the first role to distill"; return }
    [string[]]$rows = @($sources | ForEach-Object { New-Row $_ })
    $lines = @(Insert-Rows ([System.IO.File]::ReadAllLines((Join-Path $Src 'templates/context.md'))) $rows)
    Replace-Text $map (($lines -join "`n") + "`n")
    Say "  wrote $map with its sources; the first role you use distills them"
}

# Each Sources-table row after its header: line index, path, fingerprint, last read and state.
function Source-Rows([string[]]$Lines) {
    $rows = @()
    $inSources = $false; $header = $false
    for ($k = 0; $k -lt $Lines.Count; $k++) {
        $line = $Lines[$k]
        if ($line.StartsWith('## ')) { $inSources = $line -cmatch '^## Sources[ \t]*$'; $header = $false; continue }
        if (-not $inSources -or $line -cnotmatch '^[ \t]*\|' -or $line -cmatch $Separator) { continue }
        if (-not $header) { $header = $true; continue }
        $inner = ($line -replace '^[ \t]*\|', '') -replace '\|[ \t]*$', ''
        $cells = @($inner.Split('|') | ForEach-Object { $_.Trim([char[]]@(' ', "`t", '`')) })
        while ($cells.Count -lt 4) { $cells += '' }
        $rows += [pscustomobject]@{ Index = $k; Path = $cells[0]; Print = $cells[1]; Last = $cells[2]; State = $cells[3] }
    }
    return $rows
}

# Mark each Sources row whose source changed or vanished, drop rows already marked removed, and add
# a row for each source no row covers (templates/context.md, Refresh).
function Refresh-Context([string]$Map) {
    [string[]]$lines = [System.IO.File]::ReadAllLines($Map)
    $inSources = $false; $table = $false
    foreach ($line in $lines) {
        if ($line.StartsWith('## ')) { $inSources = $line -cmatch '^## Sources[ \t]*$' }
        if ($inSources -and $line -cmatch $Separator) { $table = $true }
    }
    if (-not $table) { Fail "cannot refresh ${Map}: it has no Sources table (copy the table from templates/context.md)" }
    $edits = @{}
    $rooted = @()
    $changed = 0; $removed = 0; $dropped = 0
    foreach ($r in @(Source-Rows $lines)) {
        if (-not $r.Path -or $r.Path -cmatch '^<.*>$') { continue }
        if ($r.State -ceq 'removed') { $edits[$r.Index] = $null; $dropped++; continue }
        $rel = Project-Rel $r.Path
        if ($rel) { $rooted += $rel }
        if ($r.Path.Contains('://') -or $r.State -ceq 'unreachable') { continue }
        $cur = Fingerprint $r.Path
        if (-not $cur) { $mark = 'removed'; $removed++ }
        elseif ($r.State -ceq 'read' -and ($cur -cne $r.Print -or $cur -ceq 'dir:unreadable')) { $mark = 'changed'; $changed++ }
        else { continue }
        $edits[$r.Index] = "| $($r.Path) | $($r.Print) | $($r.Last) | $mark |"
    }
    [string[]]$added = @(Discovered | Where-Object { -not (Is-Covered $_ $rooted) } | ForEach-Object { New-Row $_ })
    $summary = "$changed changed, $removed removed, $dropped dropped, $($added.Count) new"
    if ($Dry) { Say "would: mark $summary in $Map"; return }
    $kept = New-Object System.Collections.Generic.List[string]
    for ($k = 0; $k -lt $lines.Count; $k++) {
        if (-not $edits.ContainsKey($k)) { $kept.Add($lines[$k]) }
        elseif ($null -ne $edits[$k]) { $kept.Add($edits[$k]) }
    }
    $out = @(Insert-Rows $kept.ToArray() $added)
    Replace-Text $Map (($out -join "`n") + "`n")
    Say "  marked $summary in $Map; the next role re-reads exactly those"
}

function Setup-Workspace {
    Workspace-Init
    New-Dir (Join-Path $Project '.mercury')
    $ignore = Join-Path $Project '.mercury/.gitignore'
    if (-not (Test-Path -LiteralPath $ignore)) { Write-Text $ignore "work/`nqueue.md`n"; Say "  wrote $ignore (ledgers and ticket titles stay local)" }
    Write-Config
    Write-Context
}

function Check-Authority {
    foreach ($pair in ($Authority -split ',')) {
        if (-not $pair.Trim()) { continue }
        $parts = $pair.Split('=')
        $action = $parts[0].Trim(); $value = if ($parts.Count -gt 1) { $parts[1].Trim() } else { '' }
        if ($Actions -notcontains $action) { Fail "unknown action $action (one of: $($Actions -join ' '))" }
        if (@('ask', 'allowed', 'never') -notcontains $value) { Fail "action $action needs ask, allowed or never" }
    }
}

function Write-Authority {
    if (-not $Authority) { return }
    $dir = Join-Path $HomeDir '.mercury'
    $file = Join-Path $dir 'authority.md'
    New-Dir $dir
    if (-not (Test-Path -LiteralPath $file)) {
        Write-Text $file "# What Mercury may do without asking. One line per answer: <action>: <ask|allowed|never> [for <project>].`n# The most specific line wins, then the last. Mercury only appends here.`n"
    }
    foreach ($pair in ($Authority -split ',')) {
        if (-not $pair.Trim()) { continue }
        $parts = $pair.Split('=')
        $action = $parts[0].Trim(); $value = if ($parts.Count -gt 1) { $parts[1].Trim() } else { '' }
        $line = if ($Scope -eq 'project') { "${action}: $value for $Project" } else { "${action}: $value" }
        if ($Dry) { Say "would: append '$line' to $file" } else { Add-Text $file "$line`n" }
    }
    Say "  recorded standing authority in $file"
}

# A folder as a person types it: quoted, or under ~.
function Folder([string]$Path) {
    $f = $Path.Trim()
    if ($f.Length -ge 2 -and (($f[0] -eq '"' -and $f[-1] -eq '"') -or ($f[0] -eq "'" -and $f[-1] -eq "'"))) { $f = $f.Substring(1, $f.Length - 2) }
    if ($f -eq '~') { $f = $HomeDir } elseif ($f.StartsWith('~/') -or $f.StartsWith('~\')) { $f = Join-Path $HomeDir $f.Substring(2) }
    return $f
}

function Ask([string]$Prompt, [string]$Default) {
    $answer = Read-Host $Prompt
    if (-not $answer) { return $Default }
    return $answer
}

function Questions {
    Say 'Mercury setup: four questions. Press Enter to take the suggestion in brackets.'
    $here = (Get-Location).Path
    if (Inside-Package $here) { $here = '' }
    $prompt = "1. Install for which project folder? Type 'all' for every project of yours."
    if ($here) { $prompt += " [$here]" }
    $where = Ask $prompt $here
    if (-not $where) { Fail 'no project folder given' }
    if ($where -eq 'all') { $script:Scope = 'user' } else { $script:Scope = 'project'; $script:Project = $where }
    $suggestion = Saved-Hosts
    if (-not $suggestion) { $suggestion = Detect-Hosts }
    $script:Hosts = Ask "2. Which assistants? copilot, claude, agents (Codex, Cursor, Gemini and others), kiro, cline [$suggestion]" $suggestion
    $q = Ask '3. Do you work a queue of tickets or issues? If so, where (for GitHub: owner/repo and a label)? [no]' 'no'
    if ($q -ne 'no') { $script:Queue = $q }
    Say '4. What may Mercury do without asking you first? Everything else it asks about.'
    Say "   Actions: $($Actions -join ' ')"
    $script:Authority = Ask '   Type action=allowed pairs separated by commas, or Enter for none: []' ''
}

# --- Main ----------------------------------------------------------------------------------------

# git prints file names in UTF-8; decode them so, and restore the console's encoding on exit.
$SavedEncoding = $null
try { $SavedEncoding = [Console]::OutputEncoding; [Console]::OutputEncoding = $Utf8 } catch { }
$OutputEncoding = $Utf8
try {
if (-not $SawFlag -and $Ask -and [Environment]::UserInteractive -and -not [Console]::IsInputRedirected) { Questions }
$Hosts = ($Hosts -replace '\s', '').ToLowerInvariant()
$Authority = ($Authority -replace '\s', '').ToLowerInvariant()
if ($Project) { $Project = Folder $Project }
if (-not $Scope) { $Scope = 'project' }
if ($Scope -eq 'project') {
    if (-not $Project) { $Project = (Get-Location).Path }
    if (-not (Test-Path -LiteralPath $Project -PathType Container)) { Fail "no such project folder: $Project" }
    $Project = (Resolve-Path -LiteralPath $Project).Path
    if (Inside-Package $Project) { Fail "$Project is the Mercury package itself: name your project with --project DIR, or use --user" }
}
$ExplicitHosts = $Hosts
if (-not $Hosts) { $Hosts = Saved-Hosts }
if (-not $Hosts) { $Hosts = Detect-Hosts }
foreach ($h in ($Hosts -split ',')) { if ($h.Trim() -and @('copilot', 'claude', 'agents', 'kiro', 'cline') -notcontains $h.Trim()) { Fail "unknown host $h (use copilot, claude, agents, kiro or cline)" } }
Check-Authority
$Other = if ($Scope -eq 'user') { 'project' } else { 'user' }
$Version = ([System.IO.File]::ReadAllText((Join-Path $Src 'VERSION'))).Trim()

$forText = if ($Project) { " for $Project" } else { '' }
Say "Mercury ${Version}: $Mode at $Scope scope$forText, hosts $Hosts"
switch ($Mode) {
    { $_ -in @('install', 'update') } {
        $roots = @(Selected-Roots $Scope $Hosts)
        Check-Roots $roots $false
        if ($Scope -eq 'project') { Check-Listing }
        foreach ($root in $roots) { Install-Root $root }
        if ($Pointer -and $Scope -eq 'project') { foreach ($f in (Pointer-Files)) { Add-Pointer $f } }
        if ($Scope -eq 'project') { Setup-Workspace }
        Write-Authority
        if ($Scope -eq 'project') {
            foreach ($root in (Selected-Roots $Other $Hosts)) {
                $v = Join-Path $root 'mercury/VERSION'
                if ((Test-Path -LiteralPath $v) -and ([System.IO.File]::ReadAllText($v).Trim() -ne $Version)) {
                    Say "  note: $root\mercury is version $([System.IO.File]::ReadAllText($v).Trim()) at $Other scope; hosts disagree on which copy wins, so update or remove it"
                }
            }
        }
        if ($Mode -eq 'update') {
            $dirs = @((Join-Path $HomeDir '.mercury/protocol'))
            if ($Project) { $dirs += (Join-Path $Project '.mercury/protocol') }
            foreach ($d in $dirs) { if (Test-Path -LiteralPath $d) { Say "  protocol additions exist in ${d}: ask the protocol-doctor to reconcile them with this version" } }
        }
        if ((",$Hosts,") -match ',copilot,' -and $Scope -eq 'project') { Say '  for the Copilot cloud agent, commit .github\skills\mercury: it reads only repository skills' }
    }
    'refresh' {
        if ($Scope -ne 'project') { Fail '--refresh-context needs a project' }
        Check-Listing
        Setup-Workspace
    }
    'uninstall' {
        $list = if ($ExplicitHosts) { $ExplicitHosts } else { 'copilot,claude,agents,kiro,cline' }
        $roots = @(Selected-Roots $Scope $list)
        Check-Roots $roots $true
        foreach ($root in $roots) { Uninstall-Root $root }
        if ($Scope -eq 'project') {
            foreach ($f in @((Join-Path $Project '.github/copilot-instructions.md'), (Join-Path $Project 'AGENTS.md'))) { Remove-Pointer $f }
            if (Test-Path -LiteralPath (Join-Path $Project '.mercury')) { Say "  left $Project\.mercury (your context, notes and records); delete it if you no longer want them" }
        }
    }
}
Say 'done'
}
finally { if ($SavedEncoding) { try { [Console]::OutputEncoding = $SavedEncoding } catch { } } }
