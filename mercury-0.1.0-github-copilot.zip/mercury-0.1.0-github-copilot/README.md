# Install Mercury 0.1.0 for GitHub Copilot

These steps are for an AI assistant. The person gave you this folder and asked you to install
Mercury. Follow the steps in order. Ask one question at a time, in plain words. Show each command
before you run it. Never put a password, token or other secret into a command or a file, and change
nothing the steps do not name.

1. Check that this folder holds `install.sh`, `install.ps1` and `skills/mercury/SKILL.md`. If one
   is missing, tell the person the package is incomplete and stop.
2. Ask where Mercury should work: in one project folder, or in all of the person's projects. For a
   project, ask for its folder and check that the folder exists.
3. Run the installer from this folder, with `<folder>` replaced by the project folder:
   - on macOS, Linux, WSL or Git Bash:
     `sh install.sh --project "<folder>" --hosts copilot --yes`
   - on Windows:
     `powershell -ExecutionPolicy Bypass -File install.ps1 -Project "<folder>" -Hosts copilot -Yes`

   For all projects, use `--user` in place of `--project "<folder>"`, or `-User` on Windows.
4. If the installer reports an error, show it to the person, fix the answer that caused it, and run
   it again. If it says it cannot list every file in the project, a folder there cannot be opened or
   the project's git index is damaged: ask the person to fix that, or in a git project to list the
   folder in `.gitignore`, and run it again. If you cannot run commands, give the person the command
   to paste into a terminal. With no terminal at all, copy the `skills/mercury` folder into
   `.github/skills` in the project, or into `~/.copilot/skills` for all projects; that is a complete
   install.
5. For a project install, read the project's documentation once, as step 4 of `INSTALL.md`
   describes. Skip this step for all projects.
6. Tell the person:
   - where Mercury was installed, from the folders the installer printed;
   - that Mercury makes no external change, such as a push, a comment or a deploy, unless they
     allow it;
   - how to start: begin a request with "use Mercury", or name a role, such as "oncall-commander"
     for an incident.

To connect a ticket queue, or to let Mercury act without asking, follow `INSTALL.md` in place of
these steps: it asks about both.
