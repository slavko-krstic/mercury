#!/usr/bin/env python3
"""Read a Jira queue completely, and change its tickets only with a write a direct read confirms,
on Jira Cloud and Jira Data Center. Standard-library Python 3.7 or later; the protocol never depends on it.

    jira.py search --site ADDRESS --jql QUERY
    jira.py issue --site ADDRESS --ticket-site SITE ID_OR_KEY
    jira.py comment --site ADDRESS --ticket-site SITE ID --op OBJECTIVE/N --body-file FILE [--public] [--resend]
    jira.py transition --site ADDRESS --ticket-site SITE ID --op OBJECTIVE/N --to STATUS
                       [--field NAME=VALUE ...] [--closing] [--resend]
    jira.py assign --site ADDRESS --ticket-site SITE ID --op OBJECTIVE/N (--account-id ID | --user NAME)
    jira.py label --site ADDRESS --ticket-site SITE ID --op OBJECTIVE/N --add LABEL

ADDRESS is where requests go, as config.md names it; SITE is the site recorded with the ticket, the
baseUrl that search prints. A call is refused when ADDRESS's baseUrl is not SITE, so a ticket of one
site is never changed on another.

Credentials come only from the environment: MERCURY_JIRA_EMAIL and MERCURY_JIRA_TOKEN, an API token,
on Cloud; MERCURY_JIRA_TOKEN alone, a personal access token, on Data Center. A token created with
scopes uses https://api.atlassian.com/ex/jira/<cloudId> as the address.

Every write names its operation, OBJECTIVE/N: the objective's slug and the write's number in it. The
script keeps one small record per operation in .mercury/work/<objective>/jira/<n>.json, created
before the first request so two runs never both send a write, and replaced whole as its state
changes. A run whose operation has a record settles it first. A comment or transition whose outcome
could not be read is sent again only with --resend, which the role passes only on the user's words.

Output is JSON lines on stdout and messages on stderr. Exit 0: done, and for a write a direct read
shows it. Exit 2: refused or incomplete, and nothing was sent. Exit 3: the write's outcome could not
be read, and its record stays unresolved.
"""

from __future__ import annotations

import argparse
import base64
import contextlib
import hashlib
import json
import os
import random
import re
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

PAGE = 100
WAIT_BUDGET = 120.0
TIMEOUT = float(os.environ.get("MERCURY_JIRA_TIMEOUT") or 30)  # seconds per request
FIELDS = ["summary", "status", "updated", "assignee", "labels", "priority", "issuetype", "created", "project"]
KEY = re.compile(r"^[A-Za-z][A-Za-z0-9_]*-[0-9]+$")
OPERATION = re.compile(r"^(\d{8}-[A-Za-z0-9][A-Za-z0-9_-]*)/([1-9][0-9]{0,5})$")
PLATFORM_TYPES = {"software", "business", "product_discovery"}
OPEN_CATEGORIES = {"new", "indeterminate"}


class Refused(Exception):
    """Nothing was sent, or the read is incomplete: exit 2."""


class Unconfirmed(Exception):
    """A write may have happened and could not be confirmed: exit 3."""


class HTTPFailure(Refused):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """Follow no redirect: urllib would send the credential on to wherever one points. A redirect
    answering a write says nothing about whether Jira processed it, so that write stays unread."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        reason = (f"{req.get_method()} {req.full_url}: Jira answered {code} with a redirect to {newurl}; the "
                  "script follows no redirect, so check the address config.md names")
        if req.get_method() == "GET":
            raise Refused(reason)
        raise Unconfirmed(reason)


OPENER = urllib.request.build_opener(NoRedirect)


def normal_site(value: str) -> str:
    parsed = urllib.parse.urlparse(value.strip())
    return urllib.parse.urlunparse((parsed.scheme.lower(), parsed.netloc.lower(), parsed.path.rstrip("/"),
                                    "", "", ""))


class Jira:
    def __init__(self, address: str):
        parsed = urllib.parse.urlparse(address.rstrip("/"))
        local = parsed.hostname in ("127.0.0.1", "localhost", "::1")
        if parsed.scheme != "https" and not (parsed.scheme == "http" and local):
            raise Refused(f"the address must be https: {address}")
        self.address = address.rstrip("/")
        token = os.environ.get("MERCURY_JIRA_TOKEN")
        if not token:
            raise Refused("MERCURY_JIRA_TOKEN is not set")
        email = os.environ.get("MERCURY_JIRA_EMAIL")
        self._auth = ("Basic " + base64.b64encode(f"{email}:{token}".encode()).decode()) if email \
            else "Bearer " + token
        info = self.call("GET", "/rest/api/2/serverInfo")
        self.cloud = str(info.get("deploymentType", "")) == "Cloud"
        self.v = "3" if self.cloud else "2"
        base = info.get("baseUrl")
        if not isinstance(base, str) or not base:
            raise Refused("serverInfo reports no baseUrl, so the site cannot be named")
        self.site = normal_site(base)

    def call(self, method: str, path: str, body=None, query=None, write: bool = False):
        """One request. A 429 waits at least its Retry-After within WAIT_BUDGET and is sent again,
        since it rejects the request unprocessed; a read also waits out a 503. A write that fails any
        other way after it may have reached Jira raises Unconfirmed."""
        url = self.address + path + ("?" + urllib.parse.urlencode(query, doseq=True) if query else "")
        data = json.dumps(body).encode("utf-8") if body is not None else None
        waited, attempt = 0.0, 0
        while True:
            request = urllib.request.Request(url, data=data, method=method, headers={
                "Authorization": self._auth, "Accept": "application/json",
                **({"Content-Type": "application/json"} if data is not None else {})})
            try:
                with OPENER.open(request, timeout=TIMEOUT) as response:
                    raw = response.read()
                    return json.loads(raw) if raw.strip() else {}
            except urllib.error.HTTPError as error:
                status, detail = error.code, error.read()[:300].decode("utf-8", "replace")
                if status == 429 or (status == 503 and not write):
                    pause = max(float(error.headers.get("Retry-After") or 0), 2 ** attempt) + random.random()
                    if waited + pause > WAIT_BUDGET:
                        raise Refused(f"{method} {path}: still limited after {waited:.0f} s ({status})")
                    time.sleep(pause)
                    waited, attempt = waited + pause, attempt + 1
                    continue
                if write and status >= 500:
                    raise Unconfirmed(f"{method} {path}: {status}")
                if status == 401:
                    raise Refused(f"{method} {path}: 401; check MERCURY_JIRA_TOKEN"
                                  + (" and MERCURY_JIRA_EMAIL" if "Basic" in self._auth else ""))
                raise HTTPFailure(status, f"{method} {path}: {status} {detail}")
            except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError) as error:
                if write:
                    raise Unconfirmed(f"{method} {path}: {error}")
                raise Refused(f"{method} {path}: {error}")


def ticket_ref(value: str) -> str:
    if value.isdigit() or KEY.match(value):
        return value
    raise Refused(f"not an issue id or key: {value!r}")


def same_site(jira: Jira, ticket_site: str) -> None:
    if normal_site(ticket_site) != jira.site:
        raise Refused(f"{jira.address} is the site {jira.site}, not the ticket's site {normal_site(ticket_site)}")


def has_order_by(jql: str) -> bool:
    """Whether ORDER BY appears outside quoted values."""
    unquoted = re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', '""', jql)
    return re.search(r"(?i)\border\s+by\b", unquoted) is not None


def row(site: str, issue: dict) -> dict:
    f = issue.get("fields") or {}
    status = f.get("status") or {}
    return {"site": site, "id": str(issue["id"]), "key": issue.get("key"), "summary": f.get("summary"),
            "status": status.get("name"), "category": (status.get("statusCategory") or {}).get("key"),
            "updated": f.get("updated"), "assignee": (f.get("assignee") or {}).get("displayName"),
            "labels": f.get("labels") or [], "priority": (f.get("priority") or {}).get("name"),
            "type": (f.get("issuetype") or {}).get("name"),
            "project_type": (f.get("project") or {}).get("projectTypeKey")}


def offset_read(fetch, what: str, hint: str = "") -> list[dict]:
    """Every item of a listing paged by offset, or Refused when the listing moved during the read.

    fetch(start) returns the page from offset start and whether the listing ends with it. Each later
    page is fetched from one item early and must begin with the last item already read: an item
    entering or leaving the listing ahead of the offset moves every later item by one, which the
    repeated item shows where a total that stays the same does not."""
    found: list[dict] = []
    while True:
        start = len(found) - 1 if found else 0
        items, last = fetch(start)
        if found and items:
            if str(items[0].get("id")) != str(found[-1].get("id")):
                raise Refused(f"the {what} moved during the read: the page from {start} does not begin "
                              "with the last item read; read again")
            items = items[1:]
        if not items and not last:
            raise Refused(f"empty page at {len(found)} of the {what}{hint}")
        found += items
        if last:
            return found


def search(jira: Jira, jql: str) -> list[dict]:
    if jira.cloud:
        parsed = jira.call("POST", "/rest/api/3/jql/parse", {"queries": [jql]}, {"validation": "strict"})
        result = (parsed.get("queries") or [{}])[0]
        if result.get("errors"):
            raise Refused("the query is not valid: " + "; ".join(result["errors"]))
        if (result.get("structure") or {}).get("orderBy"):
            raise Refused("leave ORDER BY out of the query; the reader orders by created")
    elif has_order_by(jql):
        raise Refused("leave ORDER BY out of the query; the reader orders by created")
    ordered = f"({jql}) ORDER BY created ASC"
    seen: dict[str, dict] = {}
    if jira.cloud:
        token, tokens = None, set()
        while True:
            body = {"jql": ordered, "fields": FIELDS, "maxResults": PAGE}
            if token:
                body["nextPageToken"] = token
            page = jira.call("POST", "/rest/api/3/search/jql", body)
            if page.get("warnings"):
                raise Refused(f"Jira warned the result may be incomplete: {page['warnings']}")
            for issue in page.get("issues") or []:
                seen[str(issue["id"])] = issue
            token = page.get("nextPageToken")
            if token:
                if token in tokens:
                    raise Refused("Jira repeated a page token")
                tokens.add(token)
                continue
            if page.get("isLast") is not True:
                raise Refused("Jira said more pages follow but gave no token")
            break
    else:
        total = None

        def page(start: int) -> tuple[list[dict], bool]:
            nonlocal total
            body = jira.call("POST", "/rest/api/2/search", {"jql": ordered, "startAt": start, "maxResults": PAGE,
                                                           "fields": FIELDS, "validateQuery": "strict"})
            if total is not None and body.get("total") != total:
                raise Refused(f"the queue changed during the read ({total} then {body.get('total')}); read again")
            total = body.get("total")
            if not isinstance(total, int):
                raise Refused("Data Center returned no total")
            issues = body.get("issues") or []
            end, window = start + len(issues), body.get("maxResultWindow")
            if window and end < total and end - 1 + PAGE > window:
                raise Refused(f"the queue ({total}) passes the result window ({window}); split the query by project")
            return issues, end >= total

        for issue in offset_read(page, "queue", "; split the query by project and read each part"):
            seen[str(issue["id"])] = issue
        if len(seen) != total:
            raise Refused(f"the read found {len(seen)} distinct issues and Data Center reported {total}; read again")
    return [row(jira.site, issue) for issue in seen.values()]


def read_issue(jira: Jira, ref: str) -> dict:
    return jira.call("GET", f"/rest/api/{jira.v}/issue/{ticket_ref(ref)}", query={"fields": ",".join(FIELDS)})


# --- Comment formats -----------------------------------------------------------------------------

INLINE = re.compile(r"(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\([^)\s]+\))")


def adf_inline(text: str) -> list[dict]:
    nodes = []
    for part in INLINE.split(text):
        if not part:
            continue
        if part.startswith("`") and part.endswith("`"):
            nodes.append({"type": "text", "text": part[1:-1], "marks": [{"type": "code"}]})
        elif part.startswith("**") and part.endswith("**"):
            nodes.append({"type": "text", "text": part[2:-2], "marks": [{"type": "strong"}]})
        elif part.startswith("[") and "](" in part:
            label, href = part[1:part.index("](")], part[part.index("](") + 2:-1]
            nodes.append({"type": "text", "text": label, "marks": [{"type": "link", "attrs": {"href": href}}]})
        else:
            nodes.append({"type": "text", "text": part})
    return nodes


def blocks(text: str) -> list[tuple[str, list[str]]]:
    """Paragraph, bullet, numbered and code blocks of the Markdown subset."""
    out, lines, i = [], text.splitlines(), 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("```"):
            body, i = [], i + 1
            while i < len(lines) and not lines[i].startswith("```"):
                body.append(lines[i])
                i += 1
            out.append(("code", body))
            i += 1
        elif re.match(r"^\s*[-*] ", line):
            items = []
            while i < len(lines) and re.match(r"^\s*[-*] ", lines[i]):
                items.append(re.sub(r"^\s*[-*] ", "", lines[i]))
                i += 1
            out.append(("bullets", items))
        elif re.match(r"^\s*\d+\. ", line):
            items = []
            while i < len(lines) and re.match(r"^\s*\d+\. ", lines[i]):
                items.append(re.sub(r"^\s*\d+\. ", "", lines[i]))
                i += 1
            out.append(("numbers", items))
        elif line.strip():
            para = []
            while i < len(lines) and lines[i].strip() and not re.match(r"^(```|\s*[-*] |\s*\d+\. )", lines[i]):
                para.append(lines[i].strip())
                i += 1
            out.append(("para", [" ".join(para)]))
        else:
            i += 1
    return out


def to_adf(text: str) -> dict:
    content = []
    for kind, items in blocks(text):
        if kind == "para":
            content.append({"type": "paragraph", "content": adf_inline(items[0])})
        elif kind == "code":
            content.append({"type": "codeBlock", "content": [{"type": "text", "text": "\n".join(items) or " "}]})
        else:
            content.append({"type": "bulletList" if kind == "bullets" else "orderedList", "content": [
                {"type": "listItem", "content": [{"type": "paragraph", "content": adf_inline(item)}]}
                for item in items]})
    return {"type": "doc", "version": 1, "content": content}


def to_wiki(text: str) -> str:
    def inline(s: str) -> str:
        s = re.sub(r"`([^`]+)`", r"{{\1}}", s)
        s = re.sub(r"\*\*([^*]+)\*\*", r"*\1*", s)
        return re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", r"[\1|\2]", s)
    out = []
    for kind, items in blocks(text):
        if kind == "para":
            out.append(inline(items[0]))
        elif kind == "code":
            out.append("{code}\n" + "\n".join(items) + "\n{code}")
        else:
            mark = "*" if kind == "bullets" else "#"
            out.append("\n".join(f"{mark} {inline(item)}" for item in items))
    return "\n\n".join(out)


def adf_text(node) -> str:
    if isinstance(node, dict):
        return (node.get("text") or "") + "".join(adf_text(c) for c in node.get("content") or [])
    return "".join(adf_text(c) for c in node) if isinstance(node, list) else str(node or "")


def body_text(comment: dict) -> str:
    body = comment.get("body")
    return adf_text(body) if isinstance(body, dict) else str(body or "")


def shape(body) -> object:
    """A comment body as text, structure and link destinations, ignoring what Jira adds on its own
    (node identifiers, rendering attributes, trailing spaces and line-ending style)."""
    if isinstance(body, dict):
        marks = [(m.get("type"), (m.get("attrs") or {}).get("href")) for m in body.get("marks") or []]
        return (body.get("type"), body.get("text"), tuple(marks), tuple(shape(c) for c in body.get("content") or []))
    if isinstance(body, list):
        return tuple(shape(c) for c in body)
    return tuple(line.rstrip() for line in str(body or "").replace("\r\n", "\n").strip().split("\n"))


def carries(comment: dict, marker: str) -> bool:
    """Whether the comment ends a paragraph or line with exactly this marker, so the marker of
    operation 1 is never found inside the marker of operation 10."""
    body = comment.get("body")
    if isinstance(body, dict):
        return any(adf_text(block).strip() == marker for block in body.get("content") or [])
    return any(line.strip() == marker for line in str(body or "").splitlines())


# --- Operation records ---------------------------------------------------------------------------

def digest(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class Record:
    """One operation's record: one object, created exclusively and replaced whole, never added to."""

    def __init__(self, op: str):
        match = OPERATION.match(op or "")
        if not match:
            raise Refused(f"the operation must be <objective slug>/<number>, such as 20261025-ops-12/1: {op!r}")
        root = next((d for d in [Path.cwd(), *Path.cwd().parents] if (d / ".mercury").is_dir()), None)
        if root is None:
            raise Refused("no .mercury directory here or above; run from the project")
        objective = root / ".mercury" / "work" / match.group(1)
        if not objective.is_dir():
            raise Refused(f"no objective {match.group(1)} under {root / '.mercury' / 'work'}")
        self.op, self.directory = op, objective / "jira"
        self.path = self.directory / f"{match.group(2)}.json"

    def load(self) -> dict | None:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except ValueError as error:
            raise Refused(f"{self.path} is not a record this script wrote: {error}")

    def create(self, state: dict) -> bool:
        """Create the record, whole, if no run has; False when another run holds it. The object is
        written to a temporary file and linked into place, so no reader ever sees half of it."""
        self.directory.mkdir(exist_ok=True)
        payload = json.dumps(state, sort_keys=True)
        temporary = self.path.with_name(f"{self.path.name}.{os.getpid()}.new")
        temporary.write_text(payload, encoding="utf-8")
        try:
            os.link(temporary, self.path)
            return True
        except FileExistsError:
            return False
        except OSError:
            pass  # a filesystem without hard links: create exclusively and write at once
        finally:
            with contextlib.suppress(FileNotFoundError):
                temporary.unlink()
        try:
            fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            return False
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(payload)
        return True

    def replace(self, state: dict) -> None:
        temporary = self.path.with_name(self.path.name + f".{os.getpid()}.tmp")
        temporary.write_text(json.dumps(state, sort_keys=True), encoding="utf-8")
        os.replace(temporary, self.path)

    def unresolved_repeats(self, site: str, issue_id: str, write: str, intent: str) -> list[str]:
        """Other unresolved operations, in any objective, that would send this same write."""
        found = []
        for path in self.directory.parent.parent.glob("*/jira/*.json"):
            if path == self.path:
                continue
            try:
                other = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if (other.get("site"), other.get("id"), other.get("write"), other.get("intent")) == \
                    (site, issue_id, write, intent) and other.get("state") != "applied":
                found.append(other.get("op") or path.name)
        return found


def confirm(read_state) -> tuple[str, dict]:
    """Read a write's effect after sending it; a failed read leaves the write unconfirmed."""
    try:
        return read_state()
    except Refused as error:
        raise Unconfirmed(f"the read after the write failed: {error}") from error


def operate(jira: Jira, args, write: str, issue: dict, intent: dict, before, *, read_state, send,
            duplicates: bool) -> dict:
    """Send one write at most once per operation, settling an existing record first.

    read_state() returns ("applied", detail) when a read shows the write, ("before", detail) when it
    still shows what was recorded before the attempt, or ("other", detail) when someone changed it.
    send() sends the write, raising Refused when Jira refused it unprocessed, and returns the
    read-back detail."""
    record = Record(args.op)
    issue_id = str(issue["id"])
    meaning = digest(intent)
    state = {"op": args.op, "site": jira.site, "id": issue_id, "key": issue.get("key"), "write": write,
             "intent": meaning, "before": before, "created": now(), "updated": now(), "attempts": 1,
             "state": "sending"}
    existing = record.load()
    if existing is None:
        if duplicates and not args.resend:
            repeats = record.unresolved_repeats(jira.site, issue_id, write, meaning)
            if repeats:
                raise Refused(f"this {write} repeats unresolved operation {', '.join(repeats)}; "
                              "send it again only with --resend, on the user's words")
        if not record.create(state):
            existing = record.load()
    if existing is not None:
        if (existing.get("site"), existing.get("id"), existing.get("write"), existing.get("intent")) != \
                (jira.site, issue_id, write, meaning):
            raise Refused(f"operation {args.op} is already a different write; use a new number")
        if existing.get("state") == "applied":
            return {"op": args.op, "result": "already applied", "issue": issue_id}
        found, detail = read_state()
        if found == "applied":
            record.replace({**existing, "state": "applied", "updated": now()})
            return {"op": args.op, "result": "already applied", **detail}
        if found == "other":
            raise Refused(f"the ticket changed since the attempt ({detail}); nothing was sent")
        if duplicates and not args.resend:
            raise Unconfirmed(f"operation {args.op} is unresolved and a repeat could duplicate it; "
                              "send it again only with --resend, on the user's words")
        state = {**existing, "attempts": int(existing.get("attempts") or 1) + 1, "state": "sending",
                 "updated": now()}
        record.replace(state)
    try:
        result = send()
    except Unconfirmed as unconfirmed:
        try:
            found, detail = read_state()
        except (Refused, Unconfirmed):
            found, detail = "unread", {}
        if found == "applied":
            record.replace({**state, "state": "applied", "updated": now()})
            return {"op": args.op, "result": "applied", **detail}
        record.replace({**state, "state": "unresolved", "updated": now()})
        raise Unconfirmed(f"{unconfirmed}; operation {args.op} is unresolved") from unconfirmed
    except Refused:
        if state["attempts"] > 1:
            record.replace({**state, "state": "unresolved", "updated": now()})
        else:
            with contextlib.suppress(FileNotFoundError):
                record.path.unlink()
        raise
    record.replace({**state, "state": "applied", "updated": now()})
    return {"op": args.op, "result": "applied", **result}


# --- Writes -------------------------------------------------------------------------------------

def comment(jira: Jira, args, text: str) -> dict:
    ref = ticket_ref(args.ticket)
    issue = read_issue(jira, ref)
    project_type = ((issue.get("fields") or {}).get("project") or {}).get("projectTypeKey")
    platform = project_type in PLATFORM_TYPES
    if args.public and platform:
        raise Refused("--public applies only to a service-management issue")
    issue_id = str(issue["id"])
    marker = f"mercury: {args.op}"
    full = text.rstrip() + "\n\n" + marker

    def listing() -> list[dict]:
        def page(start: int) -> tuple[list[dict], bool]:
            if platform:
                body = jira.call("GET", f"/rest/api/{jira.v}/issue/{issue_id}/comment",
                                 query={"startAt": start, "maxResults": 100})
                values = body.get("comments") or []
                return values, start + len(values) >= int(body.get("total") or 0)
            body = jira.call("GET", f"/rest/servicedeskapi/request/{issue_id}/comment",
                             query={"start": start, "limit": 50, "public": "true", "internal": "true"})
            return body.get("values") or [], bool(body.get("isLastPage", True))

        return offset_read(page, "comments")

    def shown(c: dict) -> dict:
        public = bool(c.get("public")) if not platform else None
        if not platform and public != args.public:
            raise Unconfirmed(f"comment {c.get('id')} is {'public' if public else 'internal'}, not as intended")
        return {"comment": str(c.get("id")), "issue": issue_id, "marker": marker, "public": public,
                "route": "platform" if platform else "request"}

    sent = to_adf(full) if platform and jira.cloud else to_wiki(full)
    expected = shape(sent)

    def read_state():
        mine = next((c for c in listing() if carries(c, marker)), None)
        if mine is None:
            return "before", {}
        if shape(mine.get("body")) != expected:
            return "other", {"comment": str(mine.get("id")), "marker": marker}
        return "applied", shown(mine)

    def send() -> dict:
        try:
            if platform:
                jira.call("POST", f"/rest/api/{jira.v}/issue/{issue_id}/comment", {"body": sent}, write=True)
            else:
                jira.call("POST", f"/rest/servicedeskapi/request/{issue_id}/comment",
                          {"body": sent, "public": bool(args.public)}, write=True)
        except HTTPFailure as failure:
            raise Refused(f"{failure}; nothing was sent through the platform API, which would make it public") \
                from failure
        found, detail = confirm(read_state)
        if found != "applied":
            raise Unconfirmed("the comment does not read back with its marker")
        return detail

    if Record(args.op).load() is None:
        found, detail = read_state()
        if found == "applied":
            return {"op": args.op, "result": "already posted", **detail}
        if found == "other":
            raise Refused(f"comment {detail['comment']} carries {marker} with other text; nothing was sent: "
                          "show the user, or use a new operation number")
    return operate(jira, args, "comment", issue, {"text": text, "public": bool(args.public),
                                                 "route": "platform" if platform else "request"},
                   None, read_state=read_state, send=send, duplicates=True)


def transition(jira: Jira, args) -> dict:
    ref = ticket_ref(args.ticket)
    issue = read_issue(jira, ref)
    issue_id = str(issue["id"])
    target = args.to.lower()
    current = str(((issue.get("fields") or {}).get("status") or {}).get("name", ""))
    existing = Record(args.op).load()
    before = existing.get("before") if existing else current
    if existing is None and current.lower() == target:
        return {"op": args.op, "issue": issue_id, "status": current, "result": "already there"}

    def plan() -> tuple[dict, dict]:
        options = jira.call("GET", f"/rest/api/{jira.v}/issue/{issue_id}/transitions",
                            query={"expand": "transitions.fields"})
        offered = options.get("transitions") or []
        matches = [t for t in offered if str((t.get("to") or {}).get("name", "")).lower() == target]
        if len(matches) != 1:
            names = sorted({(t.get("to") or {}).get("name") for t in offered})
            raise Refused(f"{len(matches)} transitions lead to {args.to!r}; available targets: {names}")
        chosen = matches[0]
        category = ((chosen.get("to") or {}).get("statusCategory") or {}).get("key")
        if category not in OPEN_CATEGORIES and not args.closing:
            raise Refused(f"{args.to!r} is in the {category or 'unknown'} category and may close the ticket: "
                          "pass --closing, only with close_ticket at REMEDIATION_SUCCESSFUL")
        given = dict(f.split("=", 1) for f in args.field)
        values = {}
        for fid, meta in (chosen.get("fields") or {}).items():
            name = meta.get("name", fid)
            value = given.pop(fid, None) or given.pop(name, None) or given.pop(str(name).lower(), None)
            if value is None:
                if meta.get("required") and not meta.get("hasDefaultValue"):
                    raise Refused(f"the transition needs {name}: pass --field {fid}=<value>")
                continue
            allowed = meta.get("allowedValues")
            if allowed:
                pick = next((a for a in allowed if value in (str(a.get("name")), str(a.get("id")),
                                                             str(a.get("value")))), None)
                if pick is None:
                    raise Refused(f"{name} must be one of {[a.get('name') or a.get('value') for a in allowed]}")
                values[fid] = {"id": pick["id"]}
            else:
                values[fid] = value
        if given:
            raise Refused(f"the transition has no field {sorted(given)}")
        return chosen, values

    planned = plan() if existing is None else None

    def read_state():
        now_status = str(((read_issue(jira, issue_id).get("fields") or {}).get("status") or {}).get("name", ""))
        if now_status.lower() == target:
            return "applied", {"issue": issue_id, "status": now_status}
        return ("before" if now_status == before else "other"), {"issue": issue_id, "status": now_status}

    def send() -> dict:
        chosen, values = planned or plan()
        try:
            jira.call("POST", f"/rest/api/{jira.v}/issue/{issue_id}/transitions",
                      {"transition": {"id": chosen["id"]}, **({"fields": values} if values else {})}, write=True)
        except HTTPFailure as failure:
            raise Refused(str(failure)) from failure
        found, detail = confirm(read_state)
        if found != "applied":
            raise Unconfirmed(f"the ticket reads back at {detail.get('status')!r}, not {args.to!r}")
        return detail

    return operate(jira, args, "transition", issue, {"to": target, "fields": sorted(args.field)}, before,
                   read_state=read_state, send=send, duplicates=True)


def assign(jira: Jira, args) -> dict:
    ref = ticket_ref(args.ticket)
    if jira.cloud != bool(args.account_id) or not (args.account_id or args.user):
        raise Refused("use --account-id on Cloud and --user on Data Center")
    wanted = args.account_id or args.user
    issue = read_issue(jira, ref)
    issue_id = str(issue["id"])

    def who(fields: dict):
        person = fields.get("assignee") or {}
        return person.get("accountId") if jira.cloud else person.get("name")

    existing = Record(args.op).load()
    before = existing.get("before") if existing else who(issue.get("fields") or {})

    def read_state():
        now_who = who(read_issue(jira, issue_id).get("fields") or {})
        if now_who == wanted:
            return "applied", {"issue": issue_id, "assignee": now_who}
        return ("before" if now_who == before else "other"), {"issue": issue_id, "assignee": now_who}

    def send() -> dict:
        try:
            jira.call("PUT", f"/rest/api/{jira.v}/issue/{issue_id}/assignee",
                      {"accountId": wanted} if jira.cloud else {"name": wanted}, write=True)
        except HTTPFailure as failure:
            raise Refused(str(failure)) from failure
        found, detail = confirm(read_state)
        if found != "applied":
            raise Unconfirmed(f"the assignee reads back as {detail.get('assignee')!r}")
        return detail

    return operate(jira, args, "assign", issue, {"assignee": wanted}, before, read_state=read_state, send=send,
                   duplicates=False)


def label(jira: Jira, args) -> dict:
    ref = ticket_ref(args.ticket)
    issue = read_issue(jira, ref)
    issue_id = str(issue["id"])

    def read_state():
        labels = (read_issue(jira, issue_id).get("fields") or {}).get("labels") or []
        return ("applied" if args.add in labels else "before"), {"issue": issue_id, "labels": labels}

    def send() -> dict:
        try:
            jira.call("PUT", f"/rest/api/{jira.v}/issue/{issue_id}", {"update": {"labels": [{"add": args.add}]}},
                      write=True)
        except HTTPFailure as failure:
            raise Refused(str(failure)) from failure
        found, detail = confirm(read_state)
        if found != "applied":
            raise Unconfirmed(f"the labels read back without {args.add!r}")
        return detail

    before = args.add in ((issue.get("fields") or {}).get("labels") or [])
    return operate(jira, args, "label", issue, {"add": args.add}, before, read_state=read_state, send=send,
                   duplicates=False)


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("search", "issue", "comment", "transition", "assign", "label"):
        p = sub.add_parser(name)
        p.add_argument("--site", required=True, help="the address config.md names")
        if name == "search":
            p.add_argument("--jql", required=True)
            continue
        p.add_argument("--ticket-site", required=True, help="the site recorded with the ticket")
        p.add_argument("ticket")
        if name == "issue":
            continue
        p.add_argument("--op", required=True, help="<objective slug>/<number>")
        if name in ("comment", "transition"):
            p.add_argument("--resend", action="store_true", help="only on the user's words")
        if name == "comment":
            p.add_argument("--body-file", required=True)
            p.add_argument("--public", action="store_true")
        if name == "transition":
            p.add_argument("--to", required=True)
            p.add_argument("--field", action="append", default=[])
            p.add_argument("--closing", action="store_true")
        if name == "assign":
            p.add_argument("--account-id")
            p.add_argument("--user")
        if name == "label":
            p.add_argument("--add", required=True)
    args = parser.parse_args(argv)
    if not hasattr(args, "resend"):
        args.resend = False
    try:
        jira = Jira(args.site)
        if args.command == "search":
            rows = search(jira, args.jql)
            for r in rows:
                print(json.dumps(r, sort_keys=True))
            print(json.dumps({"complete": True, "count": len(rows)}))
            return 0
        same_site(jira, args.ticket_site)
        if args.command == "issue":
            try:
                found = read_issue(jira, args.ticket)
            except HTTPFailure as failure:
                if failure.status in (403, 404):
                    print(json.dumps({"site": jira.site, "ticket": args.ticket, "accessible": False,
                                      "reason": f"{failure.status}: missing, or not visible to this credential"}))
                    return 2
                raise
            print(json.dumps({**row(jira.site, found), "accessible": True}, sort_keys=True))
        elif args.command == "comment":
            with open(args.body_file, encoding="utf-8") as f:
                print(json.dumps(comment(jira, args, f.read()), sort_keys=True))
        elif args.command == "transition":
            print(json.dumps(transition(jira, args), sort_keys=True))
        elif args.command == "assign":
            print(json.dumps(assign(jira, args), sort_keys=True))
        else:
            print(json.dumps(label(jira, args), sort_keys=True))
        return 0
    except Unconfirmed as error:
        print(json.dumps({"confirmed": False, "reason": str(error)}))
        print(f"jira.py: unresolved: {error}", file=sys.stderr)
        return 3
    except Refused as error:
        if args.command == "search":
            print(json.dumps({"complete": False, "reason": str(error)}))
        print(f"jira.py: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
