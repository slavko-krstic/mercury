# Installing Mercury with an assistant

These are the steps an assistant follows when someone opens this folder and says "install
Mercury". The person may not be an engineer. Ask one question at a time, in plain words, and
offer the suggestion in brackets as the default. Run nothing until the four answers are in.

Install only what these steps name. Commit, push or change nothing else, and never put a password,
token or other secret into a command or a Mercury file.

## 1. Check the package

This folder must contain `skills/mercury/SKILL.md`, `install.sh` and `install.ps1`. If any is
missing, say the download is incomplete and stop.

## 2. Ask four questions

1. Where should Mercury work? Ask for the project folder, suggesting the folder the person
   usually works in. "All my projects" means `--user`; a folder means `--project "<folder>"`.
   Confirm that the folder exists.
2. Which assistants do they use? Suggest the one you are running in, plus any the person names.
   Explain the choices in their words:
   - `copilot`: GitHub Copilot in VS Code, Visual Studio, JetBrains, the Copilot CLI or GitHub's
     cloud agent;
   - `claude`: Claude Code;
   - `agents`: Codex CLI, Cursor, Gemini CLI and other assistants that read `.agents/skills`;
   - `kiro`: Kiro; `cline`: Cline.

   Pass them as `--hosts`, separated by commas.
3. Do they work through a queue of tickets or issues? [no] If so, ask where it lives.
   - For GitHub issues, ask for the repository (`owner/name`) and the label. Pass
     `--queue "<owner/name> label <label>"` and
     `--queue-read "gh issue list --repo <owner/name> --label <label> --state open --limit 1000 --json number,title,updatedAt"`.
   - For Jira, ask for the site address and the query (JQL) that selects the queue. Pass
     `--queue "jira <site> <query>"` and
     `--queue-read "python3 <skill folder>/scripts/jira.py search --site <site> --jql '<query>'"`.
     Tell them to set `MERCURY_JIRA_EMAIL` and `MERCURY_JIRA_TOKEN` (an API token) in their own
     environment, or `MERCURY_JIRA_TOKEN` alone (a personal access token) on Jira Data Center, and
     never to paste a token into a file or a chat.
   - For any other system, pass where it lives as `--queue`, and ask for the exact command or
     tool search that lists every open item as `--queue-read`. If they do not know it, leave it
     out; the on-call roles ask for it the first time they need it.
4. Is there anything Mercury may do without asking first? [nothing] Explain that Mercury
   otherwise asks before every one of these:
   - `push`: send commits to the shared repository, never forcing and never to the default
     branch;
   - `open_pull_request`, `comment` (on pull requests, issues or tickets), `change_ticket`;
   - `close_ticket`: close a ticket, only once its fix is verified;
   - `message_people`, `deploy`, `change_production`.

   Pass the answers as `--authority`, for example `--authority push=allowed,deploy=never`. An
   action they forbid outright is `never`; one they leave out stays `ask`.

## 3. Run the installer

Show the person the command, then run it. On macOS, Linux, WSL or Git Bash:

```sh
sh install.sh --project "<folder>" --hosts <hosts> [--queue "<queue>"] [--queue-read "<command>"] [--authority <answers>] --yes
```

On Windows:

```powershell
powershell -ExecutionPolicy Bypass -File install.ps1 -Project "<folder>" -Hosts <hosts> [-Queue "<queue>"] [-QueueRead "<command>"] [-Authority <answers>] -Yes
```

Use `--user` (or `-User`) instead of `--project` for all projects. The `-ExecutionPolicy Bypass`
part lets this one unsigned script run without changing the computer's settings.

If the installer reports an error, show it, fix the answer that caused it, and run it again. If
it says it cannot list every file in the project, a folder there cannot be opened or the project's
git index is damaged: ask the person to fix that, or in a git project to list the folder in
`.gitignore`, and run it again. If you cannot run commands, give the person the command to paste
into a terminal and wait for its output. Without a terminal, copying the `skills/mercury` folder into the skill folder of each
assistant is a complete install:

| Assistant | Project skill folder | Skill folder for all projects |
| --- | --- | --- |
| GitHub Copilot | `.github/skills` | `~/.copilot/skills` |
| Claude Code | `.claude/skills` | `~/.claude/skills` |
| Codex CLI, Cursor, Gemini CLI and others | `.agents/skills` | `~/.agents/skills` |
| Kiro | `.kiro/skills` | `~/.kiro/skills` |
| Cline | `.claude/skills` | `~/.cline/skills` |

## 4. Read the project's documentation once

For a project install, open the project's `.mercury/context.md`. The installer listed the
project's instruction files, READMEs, documentation folders, runbooks, build files and CI
definitions in its Sources table. Follow the procedure in the comment at the end of that file:

- read each listed source and write what a role needs from it under the matching section, one
  line per fact;
- set each row's state to `read` and its last-read date to the date you read it, keeping its
  fingerprint;
- ask whether there are other sources, such as a wiki, a dashboard or another repository, and add
  each one you can reach, or list it under Unreachable sources with the reason;
- keep the file under 12 KB, and change nothing outside `.mercury/`.

For an install covering all projects, skip this step. The first role used in a project reads its
documentation then.

## 5. Tell the person what happened

Say, in plain words:

- where Mercury was installed, from the folders the installer printed;
- how many sources the context map lists, and any you could not reach;
- what Mercury may do without asking, or that it will ask before every external change;
- how to start: say "use Mercury", or name a role, such as "oncall-commander" for an incident;
- how to keep it current: corrections go in `.mercury/notes.md`, "refresh mercury context" rereads
  changed documentation, `sh install.sh --update --project "<folder>"` installs a new version for
  the assistants they chose, and `sh install.sh --uninstall --project "<folder>"` removes it (on
  Windows, the same options after `powershell -ExecutionPolicy Bypass -File install.ps1`).

If they chose `copilot` and their team uses GitHub's Copilot cloud agent, tell them to commit
`.github/skills/mercury`, because that agent reads only skills in the repository. Commit it
yourself only if they ask.

## Chat assistants without files

Microsoft 365 Copilot and Copilot Studio cannot run the installer or read a project. Paste
[chat/mercury-chat.md](chat/mercury-chat.md) into the assistant's instructions. Where custom
skills are enabled, the zipped `skills/mercury` folder can also be uploaded as a skill.
