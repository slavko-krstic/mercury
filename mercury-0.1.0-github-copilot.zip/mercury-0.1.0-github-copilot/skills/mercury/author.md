# Author

## In short

Write, fix or review code and documents. Tier 0: run the covering check, report it. Tier 1: frame,
claims, implement, pre-review gate, then a fresh review of a commit: discovery, then the
requirements; answer findings in threads, fix with the escape audit, advance until clean. Tier 2
adds a reviewed plan, tests from requirements, milestone reviews, final verification. Asked to
review: yours, then a blind counterpart's. Ends READY or BLOCKED.

## Tiers

- **Tier 0.** Make the change, run the check that covers it, report the command and its output. It
  keeps no ledger.
- **Tier 1.** Frame (rule `frame`) and write claims with checks; implement; pass the pre-review gate;
  review a committed revision (Lanes, Review sequence); answer every finding in its thread; fix with
  the escape audit; advance until clean; READY.
- **Tier 2.** Before code, a fresh counterpart reviews the plan: requirements, design claims, planned
  checks. For behavior with a testable specification, another fresh counterpart writes acceptance
  tests from the requirements alone, never seeing the implementation, into its result file; add them
  to the work unchanged, recording any you had to adapt and why. Implement in milestones, each with a
  review that stays open across its advances until clean. Then a final comprehensive review,
  plus one aspect specialist for each high-risk dimension the plan names (correctness and
  concurrency; boundaries and compatibility; operations and security; design and simplicity); fixes;
  then one fresh verification of the final tree; READY. One comprehensive reviewer is the default:
  specialists cost several times as much for a few points of recall.

## Review sequence

Every tier that reviews follows this table. The first round is discovery without the requirements;
whatever it returns, the same counterpart (continued where the host allows, otherwise a fresh one
given that check's brief and thread state) then gets the requirements for conformance, so a required
behavior the work omits is a finding even when discovery was clean.

| From | Outcome | To |
| --- | --- | --- |
| start | work committed as rev<n> | discovery |
| discovery | any result | conformance |
| conformance | findings | threads |
| conformance | clean | review-clean |
| threads | a finding confirmed | remediation |
| threads | none confirmed | review-clean |
| remediation | gate and audit list pass | advance |
| advance | rev<n+1> briefed | reaffirm |
| reaffirm | findings | threads |
| reaffirm | clean | review-clean |
| review-clean | Tier 1 | READY |
| review-clean | Tier 2 | verification |
| verification | findings | threads |
| verification | clean | READY |

At Tier 2 the final verification receives the work, the observations and the requirements, and no
earlier thread.

In a review thread the counterpart opens findings and you answer each: `confirm` with your own
reproduction, then fix; `challenge` with counter-evidence; `question`; or `revise` to a narrower claim
with a check. Never open findings yourself: put your own concerns into the work before review.

## Reviewing a change you did not write

The report is the work, Tier 1 at least. Review the change yourself, reproducing each candidate
defect in its own thread. Then a fresh counterpart reviews it given only the change and its purpose,
never your candidates; confirm each defect it adds by your own reproduction or challenge it with
evidence. Report confirmed defects first, each with file, line and reproduction, then what you
checked and found sound. Change nothing under review.

## Lanes: the reviewed bytes stay fixed

A counterpart reads only while the tree equals a committed revision, and you remediate only while no
counterpart reads. Run the git commands from the project directory.

1. **Revision.** Commit the work locally and record `rev<n>`, its commit and the range `<base>..rev<n>`
   in `## Revisions`. Stage exactly the paths the objective changed (`git add -- <paths>`), never
   everything. If tracked files already held changes that are not the objective's, ask the user
   whether to commit them first or to work in a separate worktree; never stash or discard them. On
   the repository's default branch, first create the local branch `mercury/<objective>`. Never
   rewrite, push or merge these commits without authority; the user squashes or merges them. One
   author objective works in a working tree at a time: finding another's `IN_PROGRESS` author ledger,
   ask the user for a separate clone or worktree.
2. **Guard.** Before starting or continuing any counterpart, check that `git rev-parse HEAD` is the
   revision it is to read and that `git diff --quiet HEAD -- . ':(exclude).mercury'` succeeds. A
   failed guard stops the brief. With Python 3, then run `scripts/check.py lane start --brief <brief>`.
3. **Reading.** The counterpart records the tree at its start and finish (`delegation.md`). When the
   result arrives, run `scripts/check.py lane finish --brief <brief>`, which also catches an edit made
   and undone while it read, unless the undo restored the file's modification time. Record the
   interval per result in `## Revisions`: `checked`, `changed` or, without Python, `unchecked` (and
   ask the user not to edit during reviews). A result whose records differ is re-checked on a clean
   revision and never applied.
4. **Remediation.** Edit only after the round settles: the counterpart has returned and every
   candidate is confirmed, withdrawn or disputed. Your first edits are the escape audit's (rule
   `audit`): each confirmed finding's check, written first and seen to fail on `rev<n>`, its output kept
   as the audit entry's witness.
5. **Advance.** Run the pre-review gate on the delta and the whole audit list (each new check now
   passes), commit `rev<n+1>`, and brief the same counterpart (or a fresh one given the brief, the
   thread state and the delta) with `rev<n+1>` and `rev<n>..rev<n+1>`. Every open or confirmed finding
   returns to `needs reaffirmation`, and the counterpart completes its coverage checklist again on
   `rev<n+1>`, starting from the delta. Parallel checks of `rev<n>` advance together once each has
   returned.
6. **Without git**, or when the user or the sandbox does not allow a commit, the reviewed paths and
   their modification times stand in for the revision (`scripts/check.py lane start --brief <brief> --
   <paths>`), and the same order holds.

## Pre-review gate

Before each delegated review:

1. Re-verify the work against the requirements and the changed and coupled paths: callers, tests,
   configuration, generated files.
2. Try to break it by running concrete boundary, failure, concurrency and compatibility cases;
   execute them, never reread instead.
3. Standing checklist: identifiers unique under retry and replay; authority valid for the whole
   effect and bounded in extent (empty, wildcard, cross-tenant and stale cases); what proves each
   obligation done and what removes it; every new write's reader and cleanup; every exception or
   fallback's ending condition and the check that fails if it outlives it; whether each check proves
   its own proposition; whether the platform already provides the mechanism; every claim that
   depends on a changed limit; case-insensitive searches read in context.
4. Rerun the whole audit list.

## Validation and design

- Focused checks per revision; the full suite once at the end; reuse a result whose inputs did not
  change.
- `principles.md` guides the plan and every review; name it in every review brief's `read:` line.
  A design finding needs a concrete cost: duplicated behavior, divergent semantics, avoidable
  complexity, missed reuse, an inconsistent boundary.

## GitHub

Push and open a pull request only within authority. Its description opens with a plain summary of
what changed, why, and what the evidence shows, measured facts only. Once it exists, read every
automated and human review comment and give each a disposition: fixed in a named commit, or declined
with the reason; reply only within authority. Treat an automated reviewer's comments as findings
to verify. A Jira ticket is read and written through `jira.md`.

## Finish

READY requires every review clean under rule `stop`, every decisive claim checked, every confirmed
finding addressed, the audit list passing, and the report written. BLOCKED names what is waited on,
who owns it, and the unblock action. The report gives what changed and why, the evidence, the final
revision range, how many results had an unchecked interval, the token totals and how they were
measured, and whether protocol gaps were recorded.
