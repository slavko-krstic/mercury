# Jira

Read this when the queue or ticket is in Jira, Cloud or Data Center. `scripts/jira.py` carries the
rules below; without it, follow them by hand.

## Reading the queue

`python3 <skill>/scripts/jira.py search --site <address> --jql '<query>'`, with the query from
`config.md` and no `ORDER BY`. Each line is one issue with its `site`, `id` and `key`; the last is
`{"complete": true, "count": N}`. Exit 2 means the read is incomplete: change nothing and read again
next run. The address is the site, or `https://api.atlassian.com/ex/jira/<cloudId>` for a token
created with scopes.

Credentials come only from the environment: `MERCURY_JIRA_EMAIL` and `MERCURY_JIRA_TOKEN` on Cloud,
`MERCURY_JIRA_TOKEN` (a personal access token) on Data Center. Never put a token in a command, a
file or a message.

Without Python, on Cloud use `acli jira workitem search --jql '<query>' --paginate --json`. A
connected Jira tool reads a queue only if you follow its continuation token to the last page, and
an empty result from it proves nothing until the query is checked another way. Through a tool that
pages Data Center by offset, start each page after the first at the last issue already read, and read
again when it does not begin with that issue. Never read a queue with the community `jira-cli`: it
reads one Cloud page.

## Tickets

A ticket is its site and numeric id. Write it as `<site> <KEY> (<id>)` everywhere, with the site
the search printed, and take the key a read returns, since a move changes it. Give every ticket
command `--site <address>` and `--ticket-site <site>`: the script refuses an address that is
another site.

A ticket missing from a complete read is read directly: `scripts/jira.py issue --site <address>
--ticket-site <site> <id>`. Done category: resolved. Exit 2 with `"accessible": false`:
inaccessible, never resolved. Open, and missed by the next complete read too: it left the queue.

## Writing

Each write needs its authority, read first: `comment` for a comment, `change_ticket` for a
transition, an assignment or a label, `close_ticket` for a move to a Done status, only at
`REMEDIATION_SUCCESSFUL`. Every write names its operation, `--op <objective>/<n>`, a new number per
write.

- `scripts/jira.py comment ... <id> --op O --body-file F`: plain Markdown. On a service-management ticket
  it goes internal; `--public` needs the user's words for that reply.
- `scripts/jira.py transition ... <id> --op O --to "<status>" [--field name=value] [--closing]`.
- `scripts/jira.py assign ... <id> --op O --account-id <id>` on Cloud, `--user <name>` on Data Center;
  `scripts/jira.py label ... <id> --op O --add <label>`.

Exit 0: a direct read shows the write. Exit 2: nothing was sent; the message says why. Exit 3: the
outcome could not be read, and the operation is unresolved. Record it as an open unknown in your
ledger, and rerun the same command later: it reads the ticket first and sends nothing while it
cannot tell. Send a comment or transition again only with `--resend`, after the user has seen that it
is unresolved and said to; an assignment or label is resent by the rerun itself.

The script keeps each operation's record in `.mercury/work/<objective>/jira/`. Delete those files
with your briefs at a terminal state; an unresolved one blocks it.

Without the script, record each write in your ledger before sending it, and after an outcome you
could not read, read the ticket before anything else. A comment on a service-management ticket goes
only through a route that sends `public: false` and reads it back; Atlassian's CLI posts with the
project's default visibility, so never use it there.

## Hosts

The chat edition writes nothing: every write is a draft for the user. Microsoft 365 Copilot's Jira
connector is an index refreshed every 15 minutes, so a ticket read through it is a lead to confirm.
