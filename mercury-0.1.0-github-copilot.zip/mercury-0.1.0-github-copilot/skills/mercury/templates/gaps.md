mercury: 1
gap: <objective>.G<k>
date: <UTC time>
role: <the role that met it>
rule: <rule id, or the file and section>
status: open

## What happened

<the instruction, quoted, and what it made you do or prevented>

## Evidence

<ledger excerpt, command and output, or host message; at most three lines each, by reference>

## Cost

<what it cost: a wasted round, a wrong result, a blocked step, tokens>

## Safest reading taken

<how you continued>

<!--
Write one new file per gap at .mercury/protocol-gaps/<objective>.G<k>.md, where <k> counts this
objective's gaps; never edit an existing gap file. A gap already recorded gets its own file saying
"same as <gap>". Only the protocol-doctor edits a gap file once written, to set status to one of:
fixed in <change>, not a protocol gap: <reason>, declined: <reason>.
-->
